from __future__ import annotations


def test_build_slurm_script_starts_ray_allocation(monkeypatch, tmp_path):
    from graphids.exp.config import ExperimentConfig, ResourceConfig
    from graphids.exp.slurm import build_slurm_script

    monkeypatch.setenv("GRAPHIDS_SLURM_LOG_DIR", str(tmp_path / "slurm"))
    cfg = ExperimentConfig(
        experiment_name="temporal smoke",
        dataset="set_01",
        resources=ResourceConfig(
            cluster="pitzer",
            partition="gpu",
            accelerator="gpu",
            cpus_per_worker=4,
            gpus_per_worker=1.0,
            time_limit="00:30:00",
            account="pas1266",
        ),
    )
    path, script = build_slurm_script(
        cfg,
        "configs/experiments/graph_mamba_joint.yml",
        nodes=2,
    )

    assert path == tmp_path / "slurm" / "scripts" / "ray-temporal_smoke.sbatch"
    assert "#SBATCH --nodes=2" in script
    assert "#SBATCH --ntasks-per-node=1" in script
    assert "#SBATCH --job-name=ray-temporal_smoke" in script
    assert "#SBATCH --clusters=pitzer" in script
    assert "#SBATCH --partition=gpu" in script
    assert "#SBATCH --gres=gpu:1" in script
    assert "#SBATCH --cpus-per-task=4" in script
    assert "#SBATCH --time=00:30:00" in script
    assert "#SBATCH --account=pas1266" in script
    assert "export SLURM_CPUS_PER_TASK=4" in script
    assert "RAY_BASE_PORT=${GRAPHIDS_RAY_BASE_PORT:-$((20000 + (SLURM_JOB_ID % 200) * 200))}" in script
    assert "RAY_PORT=${GRAPHIDS_RAY_PORT:-${RAY_BASE_PORT}}" in script
    assert 'RAY_OBJECT_MANAGER_PORT="$((RAY_BASE_PORT + 1))"' in script
    assert 'RAY_NODE_MANAGER_PORT="$((RAY_BASE_PORT + 2))"' in script
    assert "RAY_CLIENT_SERVER_PORT" not in script
    assert 'RAY_DASHBOARD_AGENT_PORT="$((RAY_BASE_PORT + 4))"' in script
    assert 'RAY_DASHBOARD_AGENT_GRPC_PORT="$((RAY_BASE_PORT + 5))"' in script
    assert 'RAY_RUNTIME_ENV_AGENT_PORT="$((RAY_BASE_PORT + 6))"' in script
    assert 'RAY_METRICS_EXPORT_PORT="$((RAY_BASE_PORT + 7))"' in script
    assert 'RAY_MIN_WORKER_PORT="$((RAY_BASE_PORT + 20))"' in script
    assert 'RAY_MAX_WORKER_PORT="$((RAY_BASE_PORT + 119))"' in script
    assert 'RAY_TMP_DIR="${TMPDIR:-/tmp}/graphids-ray-${SLURM_JOB_ID}"' in script
    assert "RAY_START_PIDS=()" in script
    assert "export RAY_ADDRESS" in script
    assert "ray stop --force" not in script
    assert "ray start --head" in script
    assert "--include-dashboard=false" in script
    assert '--object-manager-port="${RAY_OBJECT_MANAGER_PORT}"' in script
    assert '--node-manager-port="${RAY_NODE_MANAGER_PORT}"' in script
    assert "--ray-client-server-port" not in script
    assert '--dashboard-agent-listen-port="${RAY_DASHBOARD_AGENT_PORT}"' in script
    assert '--dashboard-agent-grpc-port="${RAY_DASHBOARD_AGENT_GRPC_PORT}"' in script
    assert '--runtime-env-agent-port="${RAY_RUNTIME_ENV_AGENT_PORT}"' in script
    assert '--metrics-export-port="${RAY_METRICS_EXPORT_PORT}"' in script
    assert '--min-worker-port="${RAY_MIN_WORKER_PORT}"' in script
    assert '--max-worker-port="${RAY_MAX_WORKER_PORT}"' in script
    assert '--temp-dir="${RAY_TMP_DIR}/head"' in script
    assert 'RAY_START_PIDS+=("$!")' in script
    assert 'ray start --address="${RAY_ADDRESS}"' in script
    assert "trap cleanup_ray EXIT" in script
    assert "python -m graphids exp launch" in script
    assert "--address \"${RAY_ADDRESS}\"" in script


def test_submit_experiment_writes_script_and_calls_sbatch(monkeypatch, tmp_path):
    import subprocess

    from graphids.exp.config import ExperimentConfig, ResourceConfig
    from graphids.exp.slurm import submit_experiment

    calls: list[tuple[str, ...]] = []

    def fake_run(command, **kwargs):
        if isinstance(command, str):
            command_tuple = (command,)
        else:
            command_tuple = tuple(command)
        if command_tuple and command_tuple[0] == "sbatch":
            calls.append(command_tuple)
            return subprocess.CompletedProcess(command, 0, stdout="Submitted batch job 12345\n")
        return subprocess.CompletedProcess(command, 0, stdout="")

    monkeypatch.setenv("GRAPHIDS_SLURM_LOG_DIR", str(tmp_path / "slurm"))
    monkeypatch.setattr(subprocess, "run", fake_run)
    cfg = ExperimentConfig(
        experiment_name="temporal-smoke",
        dataset="set_01",
        resources=ResourceConfig(accelerator="gpu", gpus_per_worker=1.0, account="pas1266"),
    )

    result = submit_experiment(cfg, "configs/experiments/graph_mamba_joint.yml", nodes=2)

    assert result.job_id == "12345"
    assert result.script_path.is_file()
    assert calls == [("sbatch", str(result.script_path))]


def test_exp_submit_dry_run_cli(monkeypatch):
    from typer.testing import CliRunner

    from graphids.cli.app import app

    monkeypatch.setenv("GRAPHIDS_SLURM_LOG_DIR", "/tmp/graphids-slurm-test")
    result = CliRunner().invoke(
        app,
        ["exp", "submit", "configs/experiments/graph_mamba_joint.yml", "--dry-run"],
    )

    assert result.exit_code == 0
    assert "#SBATCH --clusters=ascend" in result.stdout
    assert "ray start --head" in result.stdout
    assert "python -m graphids exp launch" in result.stdout


def test_submission_freezes_expanded_yaml_and_dry_run_does_not_write(monkeypatch, tmp_path):
    import subprocess

    import yaml

    from graphids.exp.config import ExperimentConfig
    from graphids.exp.slurm import submit_experiment

    monkeypatch.setenv("GRAPHIDS_SLURM_LOG_DIR", str(tmp_path / "logs"))
    monkeypatch.setattr(subprocess, "run", lambda *args, **kwargs: subprocess.CompletedProcess(args[0], 0, stdout="Submitted batch job 123\n"))
    base = tmp_path / "base.yml"
    base.write_text("config:\n  trainer:\n    max_epochs: 3\n")
    leaf = tmp_path / "leaf.yml"
    leaf.write_text("extends: base.yml\nexperiment_name: frozen\ndataset: set_01\ngit_sha: test\n")
    cfg = ExperimentConfig.from_yaml(leaf)
    submit_experiment(cfg, leaf, dry_run=True)
    assert not (tmp_path / "logs").exists()
    result = submit_experiment(cfg, leaf)
    snapshot, = (tmp_path / "logs/scripts").glob("*.yml")
    assert str(snapshot) in result.script
    assert "extends" not in yaml.safe_load(snapshot.read_text())
    base.write_text("config:\n  trainer:\n    max_epochs: 99\n")
    assert ExperimentConfig.from_yaml(snapshot).config["trainer"]["max_epochs"] == 3
    submit_experiment(ExperimentConfig.from_yaml(leaf), leaf)
    assert len(list((tmp_path / "logs/scripts").glob("*.yml"))) == 2
