import numpy as np
import pytest

from scripts.graph_mamba_alert_policy_audit import (
    alert_policy,
    contiguous_runs,
    lost_run_hits,
    positive_run_metrics,
)


def timeline(n):
    return np.arange(n), 1672531200.0 + np.arange(n) * 0.01


def test_run_grouping_does_not_repeat_during_continuous_candidate():
    bins, closes = timeline(7)
    candidate = np.array([0, 1, 1, 1, 0, 1, 1], dtype=bool)
    active, notifications = alert_policy(candidate, bins, closes, 1, 0)
    np.testing.assert_array_equal(active, candidate)
    assert notifications.tolist() == [1, 5]


def test_confirmation_never_backdates_activation_and_rejects_short_pulses():
    bins, closes = timeline(7)
    active, notifications = alert_policy([1, 1, 0, 1, 1, 1, 1], bins, closes, 3, 0)
    assert np.flatnonzero(active).tolist() == [5, 6]
    assert notifications.tolist() == [5]


def test_cooldown_delays_notifications_without_changing_active_state():
    bins, closes = timeline(9)
    candidate = np.array([1, 0, 1, 1, 1, 1, 1, 0, 1], dtype=bool)
    active, notifications = alert_policy(candidate, bins, closes, 1, 0.05)
    np.testing.assert_array_equal(active, candidate)
    assert notifications.tolist() == [0, 5]
    # A separate recording must start with independent cooldown state.
    assert alert_policy(candidate, bins, closes, 1, 0.05)[1].tolist() == [0, 5]


def test_confirmation_and_notification_are_prefix_invariant():
    bins, closes = timeline(11)
    candidate = np.array([1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1], dtype=bool)
    active, notifications = alert_policy(candidate, bins, closes, 2, 0.05)
    for stop in range(1, len(bins) + 1):
        prefix_active, prefix_notifications = alert_policy(
            candidate[:stop], bins[:stop], closes[:stop], 2, 0.05
        )
        np.testing.assert_array_equal(prefix_active, active[:stop])
        np.testing.assert_array_equal(
            prefix_notifications, notifications[notifications < stop]
        )


def test_missing_bins_break_persistence_and_positive_run_proxies():
    bins = np.array([0, 1, 3, 4, 5])
    closes = bins * 0.01
    assert contiguous_runs(np.ones(5, dtype=bool), bins) == [(0, 2), (2, 5)]
    active, notifications = alert_policy(np.ones(5), bins, closes, 3, 0)
    assert np.flatnonzero(active).tolist() == [4]
    assert notifications.tolist() == [4]


def test_positive_run_metrics_distinguish_active_hits_notifications_and_misses():
    bins, closes = timeline(7)
    labels = np.array([0, 1, 1, -1, 1, 1, 0])
    result = positive_run_metrics(
        labels, bins, closes, np.array([1, 1, 1, 0, 0, 0, 0], dtype=bool), np.array([0])
    )
    assert result["runs"] == 2 and result["active_hits"] == 1
    assert result["notification_hits"] == 0
    assert result["events"][0]["active_delay_seconds"] == 0
    assert result["events"][0]["notification_delay_seconds"] is None
    assert result["events"][1]["active_delay_seconds"] is None


def test_nonmonotonic_clocks_and_duplicate_bins_are_rejected():
    with pytest.raises(ValueError, match="increasing"):
        alert_policy([1, 1], [0, 0], [0.0, 0.01], 1, 0)
    with pytest.raises(ValueError, match="increasing"):
        alert_policy([1, 1], [0, 1], [0.01, 0.0], 1, 0)


def test_equal_hit_counts_cannot_hide_a_lost_positive_run():
    def policy(first_delay, second_delay):
        return {
            "recordings": [
                {
                    "recording": "capture",
                    "positive_runs": {
                        "events": [
                            {
                                "start_bin": 10,
                                "active_delay_seconds": 0,
                                "notification_delay_seconds": first_delay,
                            },
                            {
                                "start_bin": 20,
                                "active_delay_seconds": 0,
                                "notification_delay_seconds": second_delay,
                            },
                        ]
                    },
                }
            ]
        }

    losses = lost_run_hits(policy(None, 0), policy(0, None))
    assert losses == {"active": [], "notified": [("capture", 10)]}
