import numpy as np

from graphids.diagnostics.missed_attacks import (
    ByteTransitions,
    aggregate_max,
    causal_messages,
    hierarchical_weights,
    normal_budgets,
    observed_idbins,
    physical_bins,
    source_manifest,
)


def rows():
    return [
        dict(time=t, id=k, data=bytes.fromhex(p), label=y)
        for t, k, p, y in [
            (0.0, "a", "01", 0),
            (0.001, "a", "ff", 1),
            (0.002, "a", "01", 0),
            (0.003, "b", "03", 1),
            (0.01, "a", "01", 1),
            (0.04, "a", "01", None),
        ]
    ]


def test_overwrites_multiple_ids_and_identical_payload():
    r = rows()
    units = observed_idbins(r, physical_bins([x["time"] for x in r]))
    assert units[0]["legitimate_after_attack"] == 1
    assert not units[0]["attack_payload_survives"]
    assert units[1]["id"] == "b" and units[1]["final_attacker"]
    assert units[2]["attack_payload_survives"]
    assert units[-1]["label"] == -1
    assert units[0]["first_line"] == 2 and units[0]["last_line"] == 4
    identical = [
        dict(time=t, id="a", data=b"\x01", label=label)
        for t, label in [(0.0, 0), (0.001, 1), (0.002, 0)]
    ]
    unit = observed_idbins(identical, physical_bins([r["time"] for r in identical]))[0]
    assert unit["attack_payload_survives"] and not unit["final_attacker"]
    assert unit["legitimate_after_attack"] == 1 and not unit["changed"]


def test_boundary_tolerance_and_empty_bins():
    assert physical_bins([100.0, 100.01, 100.01 - 1e-9, 100.04]).tolist() == [
        0,
        1,
        1,
        4,
    ]
    assert aggregate_max([0.2, 0.8, 0.4], [0, 0, 4], 5).tolist() == [
        np.float32(0.8),
        0,
        0,
        0,
        np.float32(0.4),
    ]


def test_future_perturbations_and_recording_reset():
    r = rows()
    x = causal_messages(r)
    changed = r[:4] + [dict(time=0.1, id="z", data=b"\x99", label=0)]
    np.testing.assert_array_equal(x[:4], causal_messages(changed)[:4])
    assert x[2, 16] == 1
    assert x[2, 33] == 2
    assert causal_messages(r[2:])[0, 32] == 0
    model = ByteTransitions().fit([r[:1]])
    np.testing.assert_array_equal(model.score(r)[:4], model.score(changed)[:4])
    assert np.isnan(model.score(r)[3])


def test_group_weights_and_unknowns():
    y = [1, 1, 1, 1, 0, 0, -1]
    w = hierarchical_weights(
        y,
        ["a", "a", "a", "b", "n", "n", "x"],
        ["v"] * 7,
        ["g", "g", "h", "i", "g", "h", "z"],
    )
    assert w[:3].sum() == 0.25 and w[3] == 0.25 and w[4:6].sum() == 0.5 and w[-1] == 0
    assert w[0] + w[1] == w[2]


def test_budgets_ties_and_zero_budget():
    b = normal_budgets(
        [0.1, 0.5, 0.5, 0.9], [0, 0, 0, 1], [1, 1, 1, 0], [360, 360, 360, 1]
    )
    assert b["0"]["false_bins"] == 0
    assert b["10"]["achieved_per_hour"] <= 10
    assert b["0"]["boundary_ties"] == 2


def test_balance_plan_matches_unit_weights():
    from collections import Counter

    from graphids.diagnostics.probes import BalancePlan

    meta = {
        "a": {"family": "gear", "recording": {"vehicle": "v", "session": "g"}},
        "b": {"family": "gear", "recording": {"vehicle": "v", "session": "g"}},
        "c": {"family": "rpm", "recording": {"vehicle": "w", "session": "h"}},
    }
    plan = BalancePlan(
        Counter({("a", 1): 2, ("b", 1): 1, ("c", 1): 1, ("a", 0): 1}), meta
    )
    assert np.isclose(plan.weights("a", [1])[0] / plan.total, 0.25 / 3)
    assert np.isclose(plan.weights("b", [1])[0] / plan.total, 0.25 / 3)
    assert np.isclose(plan.weights("c", [1])[0] / plan.total, 0.25)
    assert plan.weights("a", [-1])[0] == 0


def test_float32_budget_excludes_threshold_ties():
    b = normal_budgets(
        np.array([0.5, 0.5, 0.9], np.float32), [0, 0, 1], [1, 1, 0], [1, 1, 1]
    )
    assert b["0"]["false_bins"] == 0
    from graphids.diagnostics.missed_attacks import metrics

    assert (
        metrics(np.array([0.5, 0.9], np.float32), [0, 1], b["0"]["threshold"])["fp"]
        == 0
    )


def test_source_manifest_never_opens_target_files(tmp_path):
    import json

    from scripts.graph_mamba_gate import fixture_manifest

    path = fixture_manifest(tmp_path / "fixture")
    raw = json.loads(path.read_text())
    for r in raw["records"]:
        if r["role"].startswith("target_"):
            r["path"] = "/nonexistent/reserved-target.csv"
    raw["attack_families"] = {
        r["key"]: "normal" if r["verified_normal"] else "attack" for r in raw["records"]
    }
    path.write_text(json.dumps(raw))
    result = source_manifest(path, tmp_path / "source.json")
    assert all(r.role.startswith(("train_", "val_")) for r in result.records)


def test_stream_objective_sums_and_embedding_hooks(tmp_path):
    import torch

    from scripts.graph_mamba_missed_attacks import streaming_loss_sums
    from tests.core.models.test_graph_mamba import make_batch, model

    torch.manual_seed(42)
    batch, snapshot, context = make_batch(tmp_path)
    net = model().eval()
    captured = {}
    graph = net.graph.register_forward_hook(
        lambda m, i, out: captured.update(nodes=out)
    )
    pool = net.classifier.register_forward_pre_hook(
        lambda m, i: captured.update(pooled=i[0])
    )
    with torch.no_grad():
        out, state = net.stream(batch)
        sums, counts = streaming_loss_sums(net, batch, out, {})
        _, objective = net.losses(net(batch), batch)
    for i, name in enumerate(("classification", "count", "change", "new_id")):
        assert np.isclose(
            sums[:, i].sum() / max(1, counts[:, i].sum()),
            float(objective[name]),
            rtol=1e-5,
        )
    torch.testing.assert_close(
        net.classifier(captured["pooled"]).squeeze(-1), out["classification_logits"]
    )
    assert captured["nodes"].shape[:3] == batch.live.shape
    graph.remove()
    pool.remove()


def test_probe_normalization_and_fit_use_training_only(tmp_path):
    import json

    import torch

    from graphids.diagnostics.probes import fit_probe

    torch.set_num_threads(1)
    for key, role in [("train", "train_query"), ("validation", "val_query")]:
        audit = tmp_path / "audit" / key
        embedding = tmp_path / "embeddings" / key
        audit.mkdir(parents=True)
        embedding.mkdir(parents=True)
        (audit / "identity.json").write_text(
            json.dumps(
                dict(
                    family="gear",
                    ids=["A"],
                    recording=dict(role=role, vehicle="v", session=key),
                )
            )
        )
        x = np.array([[0.0, 1.0], [1.0, 2.0], [2.0, 3.0], [3.0, 4.0]], np.float32)
        np.savez(
            embedding / "shard-000000000.npz",
            pooled=x,
            labels=[0, 0, 1, 1],
            bin=np.arange(4),
        )
    fit_probe(tmp_path, "pooled_balanced", "cpu")
    first = torch.load(tmp_path / "probes/pooled_balanced/head.pt", weights_only=False)
    np.savez(
        tmp_path / "embeddings/validation/shard-000000000.npz",
        pooled=np.full((4, 2), 1e6),
        labels=[1, 1, 0, 0],
        bin=np.arange(4),
    )
    fit_probe(tmp_path, "pooled_balanced", "cpu")
    second = torch.load(tmp_path / "probes/pooled_balanced/head.pt", weights_only=False)
    np.testing.assert_array_equal(first["center"], [1.5, 2.5])
    np.testing.assert_array_equal(first["center"], second["center"])
    assert first["epoch"] == second["epoch"] == 10
    for key in first["head"]:
        torch.testing.assert_close(
            first["head"][key], second["head"][key], rtol=0, atol=0
        )


def test_message_scores_preserve_causality():
    import torch

    torch.manual_seed(42)
    head = torch.nn.Sequential(
        torch.nn.Linear(55, 64), torch.nn.SiLU(), torch.nn.Linear(64, 1)
    ).eval()
    r = rows()
    modified = r[:4] + [dict(time=99.0, id="a", data=b"\xff\xff", label=1)]
    with torch.no_grad():
        first = head(torch.from_numpy(causal_messages(r)))
        second = head(torch.from_numpy(causal_messages(modified)))
    torch.testing.assert_close(first[:4], second[:4], rtol=0, atol=0)


def test_idbin_aggregation_handles_unknown_and_multiple_ids():
    from graphids.diagnostics.missed_attacks import aggregate_idbins

    score, label = aggregate_idbins(
        [0.1, 0.9, 0.3, 0.8, 0.4],
        [0, -1, 1, 0, 0],
        [0, 0, 0, 1, 1],
        ["a", "a", "b", "a", "b"],
    )
    np.testing.assert_allclose(score, [0.9, 0.3, 0.8, 0.4])
    assert label.tolist() == [-1, 1, 0, 0]
    assert len(aggregate_idbins([], [], [], [])[0]) == 0


def test_stream_loss_counts_include_chunk_boundary(tmp_path):
    import torch

    from graphids.core.data.snapshots.batch import recording_batch
    from scripts.graph_mamba_missed_attacks import streaming_loss_sums
    from tests.core.models.test_graph_mamba import make_batch, model

    batch, snapshot, context = make_batch(tmp_path)
    net = model().eval()
    with torch.no_grad():
        out, _ = net.stream(batch)
        full_sum, full_count = streaming_loss_sums(net, batch, out, {})
        a = recording_batch(snapshot, context, stop=2)
        b = recording_batch(snapshot, context, start=2)
        out, state = net.stream(a)
        first_sum, first_count = streaming_loss_sums(net, a, out, {})
        prior = state.pending
        out, state = net.stream(b, state)
        second_sum, second_count = streaming_loss_sums(net, b, out, prior)
    np.testing.assert_allclose(
        full_sum, np.concatenate([first_sum, second_sum]), rtol=1e-5, atol=1e-6
    )
    np.testing.assert_array_equal(
        full_count, np.concatenate([first_count, second_count])
    )


def test_prediction_coverage_rejects_duplicate_bin(tmp_path):
    import json

    import pytest

    from graphids.diagnostics.probes import ProbeData, verify_prediction_coverage

    audit = tmp_path / "audit/train"
    embedding = tmp_path / "embeddings/train"
    prediction = tmp_path / "probes/pooled_bce/train"
    for path in (audit, embedding, prediction):
        path.mkdir(parents=True)
    (audit / "identity.json").write_text(
        json.dumps(
            dict(
                family="gear",
                ids=["A"],
                recording=dict(
                    key="train", role="train_query", vehicle="v", session="g"
                ),
            )
        )
    )
    (tmp_path / "audit/audit.json").write_text(json.dumps(dict(recordings={})))
    np.savez(audit / "bins.npz", label=[0, 1, -1])
    np.savez(audit / "idbins.npz", label=[0, 1, -1])
    np.savez(
        embedding / "shard-000000000.npz",
        pooled=np.zeros((3, 2)),
        labels=[0, 1, -1],
        bin=[0, 1, 2],
    )
    np.savez(
        prediction / "shard-000000000.npz",
        score=[0.1, 0.8, 0.2],
        label=[0, 1, -1],
        bin=[0, 1, 2],
    )
    source = ProbeData(tmp_path)
    verify_prediction_coverage(tmp_path, "pooled_bce", source)
    np.savez(
        prediction / "shard-000000000.npz",
        score=[0.1, 0.8, 0.2],
        label=[0, 1, -1],
        bin=[0, 0, 2],
    )
    with pytest.raises(AssertionError):
        verify_prediction_coverage(tmp_path, "pooled_bce", source)


def test_ddp_loss_contributions_use_global_mask_denominators():
    from graphids.diagnostics.missed_attacks import step_contributions

    names = ("classification", "count", "change", "new_id")
    normal = dict(
        family="normal",
        numerators=dict(zip(names, [64.0, 256.0, 128.0, 32.0])),
        denominators=dict(zip(names, [128, 128, 128, 32])),
    )
    attack = dict(
        family="gear",
        numerators=dict(zip(names, [128.0, 0.0, 0.0, 0.0])),
        denominators=dict(zip(names, [128, 0, 0, 0])),
    )
    result = step_contributions([normal, attack])
    assert result["normal"]["classification"] == 0.25
    assert result["gear"]["classification"] == 0.5
    assert result["normal"]["count"] == 2
    assert result["gear"]["count"] == 0


def test_false_budget_counts_zero_exposure_terminal_observations():
    result = normal_budgets([0.99, 0.1, 0.8], [0, 0, 1], [1, 1, 0], [0.0, 3600.0, 1.0])
    assert result["0"]["threshold"] > 0.99
    assert result["0"]["normal_hours"] == 1
    assert result["0"]["recall"] == 0
