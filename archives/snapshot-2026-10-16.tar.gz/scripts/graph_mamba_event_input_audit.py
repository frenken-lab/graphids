#!/usr/bin/env python3
"""Verify lossless event ingestion on the reviewed source cohort, in Slurm.

Every normalized frame field is compared with its independently reread CSV row.
No target recording is opened and no detector is trained or evaluated.
"""

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

from graphids.core.data.events.data import CANEventDataModule
from graphids.core.data.snapshots.manifest import iter_rows
from graphids.exp.config import ExperimentConfig


def verify_recording(events):
    arrays = events.arrays
    digest = hashlib.sha256()
    positives, unknown, tied = 0, 0, 0
    previous_time = None
    count = 0
    for i, row in enumerate(iter_rows(events.recording)):
        label = -1 if row["label"] is None else row["label"]
        length = len(row["data"])
        assert float(arrays["times"][i]) == row["time"], (
            events.recording.key,
            i,
            "time",
        )
        assert int(arrays["ids"][i]) == int(row["id"], 16), (
            events.recording.key,
            i,
            "id",
        )
        assert int(arrays["lengths"][i]) == length, (events.recording.key, i, "length")
        assert int(arrays["labels"][i]) == label, (events.recording.key, i, "label")
        assert arrays["payload"][i, :length].tobytes() == row["data"], (
            events.recording.key,
            i,
            "payload",
        )
        assert not arrays["payload"][i, length:].any(), (
            events.recording.key,
            i,
            "padding",
        )
        positives += label == 1
        unknown += label < 0
        tied += previous_time == row["time"]
        previous_time = row["time"]
        count += 1
    assert count == events.count
    for name, values in arrays.items():
        digest.update(name.encode())
        for lo in range(0, count, 65536):
            digest.update(values[lo : lo + 65536].tobytes())
    return dict(
        recording=events.recording.key,
        role=events.recording.role,
        vehicle=events.recording.vehicle,
        frames=count,
        positive_frames=positives,
        unknown_frames=unknown,
        equal_timestamp_successors=tied,
        input_sha256=events.recording.sha256,
        cache_fields_sha256=digest.hexdigest(),
        distinct_ids=len(np.unique(arrays["ids"])),
        status="complete",
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config", default="configs/experiments/graph_mamba_events_source.yml"
    )
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    cfg = ExperimentConfig.from_yaml(args.config)
    dm = CANEventDataModule(
        **{
            k: v
            for k, v in cfg.config["data"].items()
            if k not in ("type", "representation_cfg")
        }
    )
    result = dict(
        status="running",
        representation="can_event",
        source_only=True,
        records=[],
        trained=False,
        target_evaluated=False,
    )

    def persist():
        staging = args.output.with_suffix(".tmp")
        staging.write_text(json.dumps(result, indent=2) + "\n")
        staging.replace(args.output)

    persist()
    try:
        dm.setup()
        result["source_manifest_digest"] = dm.manifest.digest
        for events in dm.event_recordings.values():
            record = verify_recording(events)
            result["records"].append(record)
            persist()
            print(
                f"Verified {record['recording']}: {record['frames']} frames", flush=True
            )
        result["frames"] = sum(r["frames"] for r in result["records"])
        result["recordings"] = len(result["records"])
        result["status"] = "complete"
    except Exception as exc:
        result.update(status="incomplete", error=repr(exc))
        raise
    finally:
        persist()


if __name__ == "__main__":
    main()
