"""Audit causal alert policies on saved source validation scores in CPU Slurm.

Positive-label runs are diagnostic proxies, never trusted attack intervals.
This script neither fits thresholds nor reads target scores or model weights.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict
from pathlib import Path

import numpy as np


def contiguous_runs(mask, bins):
    mask = np.asarray(mask, dtype=bool)
    bins = np.asarray(bins)
    if not len(mask):
        return []
    gaps = np.diff(bins) != 1
    starts = np.flatnonzero(mask & (np.r_[True, ~mask[:-1]] | np.r_[True, gaps]))
    stops = np.flatnonzero(mask & (np.r_[~mask[1:], True] | np.r_[gaps, True])) + 1
    return list(zip(starts.tolist(), stops.tolist(), strict=True))


def alert_policy(candidate, bins, closes, persistence, cooldown):
    """Causal active state and one delayed notification per candidate run."""
    candidate = np.asarray(candidate, dtype=bool)
    bins, closes = np.asarray(bins), np.asarray(closes)
    if (
        persistence < 1
        or cooldown < 0
        or len(candidate) != len(bins)
        or len(bins) != len(closes)
    ):
        raise ValueError("invalid alert policy inputs")
    if (
        not np.isfinite(closes).all()
        or np.any(np.diff(closes) <= 0)
        or np.any(np.diff(bins) <= 0)
    ):
        raise ValueError("recording bins and clocks must be finite and increasing")
    active = np.zeros(len(candidate), dtype=bool)
    notifications = []
    last_emitted = -math.inf
    for start, stop in contiguous_runs(candidate, bins):
        confirmed = start + persistence - 1
        if confirmed >= stop:
            continue
        active[confirmed:stop] = True
        # One-microsecond tolerance avoids epoch-clock rounding adding a bin.
        first_allowed = np.searchsorted(closes, last_emitted + cooldown - 1e-6)
        emitted = max(confirmed, int(first_allowed))
        if emitted < stop:
            notifications.append(emitted)
            last_emitted = closes[emitted]
    return active, np.asarray(notifications, dtype=np.int64)


def ratio(a, b):
    return float(a / b) if b else None


def bin_metrics(labels, active):
    known = labels >= 0
    tp = int((active & (labels == 1)).sum())
    fp = int((active & (labels == 0)).sum())
    fn = int((~active & (labels == 1)).sum())
    tn = int((~active & (labels == 0)).sum())
    return dict(
        tp=tp,
        fp=fp,
        fn=fn,
        tn=tn,
        known_bins=int(known.sum()),
        precision=ratio(tp, tp + fp),
        recall=ratio(tp, tp + fn),
        f1=ratio(2 * tp, 2 * tp + fp + fn),
    )


def positive_run_metrics(labels, bins, closes, active, notifications):
    events = []
    for start, stop in contiguous_runs(labels == 1, bins):
        hits = np.flatnonzero(active[start:stop])
        within = notifications[(notifications >= start) & (notifications < stop)]
        events.append(
            dict(
                start_bin=int(bins[start]),
                stop_bin_exclusive=int(bins[stop - 1]) + 1,
                positive_bins=stop - start,
                active_delay_seconds=float(closes[start + hits[0]] - closes[start])
                if len(hits)
                else None,
                notification_delay_seconds=float(closes[within[0]] - closes[start])
                if len(within)
                else None,
            )
        )
    active_delays = [
        e["active_delay_seconds"]
        for e in events
        if e["active_delay_seconds"] is not None
    ]
    notification_delays = [
        e["notification_delay_seconds"]
        for e in events
        if e["notification_delay_seconds"] is not None
    ]
    return dict(
        runs=len(events),
        active_hits=len(active_delays),
        notification_hits=len(notification_delays),
        active_hit_fraction=ratio(len(active_delays), len(events)),
        notification_hit_fraction=ratio(len(notification_delays), len(events)),
        max_active_delay_seconds=max(active_delays, default=None),
        max_notification_delay_seconds=max(notification_delays, default=None),
        events=events,
    )


def summarize(records):
    counts = {
        key: sum(r["bins"][key] for r in records)
        for key in ("tp", "fp", "fn", "tn", "known_bins")
    }
    counts.update(
        precision=ratio(counts["tp"], counts["tp"] + counts["fp"]),
        recall=ratio(counts["tp"], counts["tp"] + counts["fn"]),
        f1=ratio(2 * counts["tp"], 2 * counts["tp"] + counts["fp"] + counts["fn"]),
    )
    normal_hours = sum(r["normal_hours"] for r in records)
    normal_notifications = sum(r["normal_notifications"] for r in records)
    normal_active = sum(r["normal_active_bins"] for r in records)
    normal_bins = sum(r["normal_bins"] for r in records)
    events = [e for r in records for e in r["positive_runs"]["events"]]
    active_delays = [
        e["active_delay_seconds"]
        for e in events
        if e["active_delay_seconds"] is not None
    ]
    notification_delays = [
        e["notification_delay_seconds"]
        for e in events
        if e["notification_delay_seconds"] is not None
    ]
    known_notifications = sum(r["known_notifications"] for r in records)
    positive_notifications = sum(r["positive_notifications"] for r in records)
    return dict(
        bins=counts,
        normal_hours=normal_hours,
        normal_bins=normal_bins,
        normal_active_bins=normal_active,
        normal_active_fraction=ratio(normal_active, normal_bins),
        normal_notifications=normal_notifications,
        normal_notifications_per_hour=ratio(normal_notifications, normal_hours),
        notifications=sum(r["notifications"] for r in records),
        known_notifications=known_notifications,
        positive_notifications=positive_notifications,
        positive_notification_fraction=ratio(
            positive_notifications, known_notifications
        ),
        positive_runs=len(events),
        active_run_hits=len(active_delays),
        notified_run_hits=len(notification_delays),
        active_run_hit_fraction=ratio(len(active_delays), len(events)),
        notified_run_hit_fraction=ratio(len(notification_delays), len(events)),
        max_active_delay_seconds=max(active_delays, default=None),
        median_notification_delay_seconds=float(np.median(notification_delays))
        if notification_delays
        else None,
        p95_notification_delay_seconds=float(np.quantile(notification_delays, 0.95))
        if notification_delays
        else None,
        max_notification_delay_seconds=max(notification_delays, default=None),
    )


def run_hits(policy, field):
    return {
        (record["recording"], event["start_bin"])
        for record in policy["recordings"]
        for event in record["positive_runs"]["events"]
        if event[field] is not None
    }


def lost_run_hits(policy, baseline):
    return {
        name: sorted(run_hits(baseline, field) - run_hits(policy, field))
        for name, field in (
            ("active", "active_delay_seconds"),
            ("notified", "notification_delay_seconds"),
        )
    }


def audit_mode(task):
    mode, groups, bundle, config = task
    policies = []
    raw_records = {head: [] for head in config["heads"]}
    contributions = []
    for group in groups:
        x = group["values"]
        labels, cls, ano, eligible, normal, exposure, bins, closes = x.T
        labels, bins = labels.astype(int), bins.astype(int)
        normal = normal.astype(bool) & (labels == 0)
        cp = cls >= bundle["thresholds"][0]
        ap = eligible.astype(bool) & (ano >= bundle["thresholds"][1])
        candidates = dict(classification=cp, anomaly=ap, combined_or=cp | ap)
        contributions.append(
            dict(
                recording=group["recording"],
                vehicle=group["vehicle"],
                classifier_only_positive_bins=int((cp & ~ap & (labels == 1)).sum()),
                forecast_only_positive_bins=int((ap & ~cp & (labels == 1)).sum()),
                forecast_only_negative_bins=int((ap & ~cp & (labels == 0)).sum()),
                forecast_only_normal_bins=int((ap & ~cp & normal).sum()),
            )
        )
        for head, candidate in candidates.items():
            raw_records[head].append(
                dict(
                    recording=group["recording"],
                    vehicle=group["vehicle"],
                    bins=bin_metrics(labels, candidate),
                )
            )
    for head in config["heads"]:
        for persistence in config["persistence_bins"]:
            for cooldown in config["cooldown_seconds"]:
                records = []
                for group in groups:
                    labels, cls, ano, eligible, normal, exposure, bins, closes = group[
                        "values"
                    ].T
                    labels, bins = labels.astype(int), bins.astype(int)
                    normal = normal.astype(bool) & (labels == 0)
                    cp = cls >= bundle["thresholds"][0]
                    ap = eligible.astype(bool) & (ano >= bundle["thresholds"][1])
                    candidate = dict(
                        classification=cp, anomaly=ap, combined_or=cp | ap
                    )[head]
                    active, notifications = alert_policy(
                        candidate, bins, closes, persistence, cooldown
                    )
                    record = dict(
                        recording=group["recording"],
                        vehicle=group["vehicle"],
                        bins=bin_metrics(labels, active),
                        normal_hours=float(exposure[normal].sum()) / 3600,
                        normal_bins=int(normal.sum()),
                        normal_active_bins=int((active & normal).sum()),
                        normal_notifications=int(normal[notifications].sum()),
                        notifications=len(notifications),
                        known_notifications=int((labels[notifications] >= 0).sum()),
                        positive_notifications=int((labels[notifications] == 1).sum()),
                        notification_bins=bins[notifications].tolist(),
                        positive_runs=positive_run_metrics(
                            labels, bins, closes, active, notifications
                        ),
                    )
                    records.append(record)
                vehicles = {
                    v: summarize([r for r in records if r["vehicle"] == v])
                    for v in sorted({r["vehicle"] for r in records})
                }
                policies.append(
                    dict(
                        head=head,
                        persistence_bins=persistence,
                        cooldown_seconds=cooldown,
                        pooled=summarize(records),
                        vehicles=vehicles,
                        recordings=records,
                    )
                )
    baseline = next(
        p
        for p in policies
        if p["head"] == "combined_or"
        and p["persistence_bins"] == 1
        and p["cooldown_seconds"] == 0
    )
    for policy in policies:
        policy["lost_baseline_positive_runs"] = lost_run_hits(policy, baseline)
        policy["preserves_baseline_positive_evidence"] = not any(
            policy["lost_baseline_positive_runs"].values()
        ) and all(
            result["bins"]["tp"] >= baseline["vehicles"][v]["bins"]["tp"]
            and result["active_run_hits"] >= baseline["vehicles"][v]["active_run_hits"]
            and result["notified_run_hits"]
            >= baseline["vehicles"][v]["notified_run_hits"]
            for v, result in policy["vehicles"].items()
        )
    return mode, dict(
        raw_bins=raw_records, forecast_contributions=contributions, policies=policies
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    from graphids.core.data.snapshots.manifest import CANRecordingManifest

    config = json.loads(args.protocol.read_text())
    manifest = CANRecordingManifest.load(args.manifest, verify_files=False)
    expected = {r.key: r for r in manifest.records if r.role == "val_query"}
    source_digest = hashlib.sha256(
        json.dumps(
            [
                asdict(r)
                for r in manifest.records
                if r.role.startswith(("train_", "val_"))
            ],
            sort_keys=True,
        ).encode()
    ).hexdigest()
    bundles_path = args.source_root / "frozen-source-calibration-v2.json"
    bundles = json.loads(bundles_path.read_text())
    assert all(
        b["track"] == "source-normal" and b["source_manifest"] == source_digest
        for b in bundles.values()
    )
    assert len({b["checkpoint_hash"] for b in bundles.values()}) == 1
    groups = {}
    score_path = args.source_root / "source-scores-v2.jsonl"
    with score_path.open() as handle:
        for line in handle:
            row = json.loads(line)
            if row["role"] != "val_query" or row["recording"] not in expected:
                raise ValueError("audit accepts source validation scores only")
            rec = expected[row["recording"]]
            if row["vehicle"] != rec.vehicle or row["normal"] != rec.verified_normal:
                raise ValueError(
                    "score vehicle or normality differs from source manifest"
                )
            mode = "zero-shot" if row["context"] == "zero-shot" else "conditioned"
            available = any(
                a and b
                for a, b in zip(
                    row["anomaly_component_mask"],
                    bundles[mode]["available"],
                    strict=True,
                )
            )
            group = groups.setdefault(
                (mode, rec.key), dict(recording=rec.key, vehicle=rec.vehicle, values=[])
            )
            group["values"].append(
                (
                    row["label"],
                    row["classification"],
                    row["anomaly"],
                    row["anomaly_eligible"] and available,
                    row["normal"],
                    row["exposure"],
                    row["bin"],
                    row["close"],
                )
            )
    for mode in bundles:
        assert {key for m, key in groups if m == mode} == set(expected)
    original = json.loads((args.source_root / "source-metrics-v2.json").read_text())[
        "groups"
    ]
    for (mode, key), group in groups.items():
        x = np.asarray(group["values"], dtype=np.float64)
        x = x[np.argsort(x[:, 6], kind="stable")]
        if (
            not np.isfinite(x).all()
            or x[0, 6] != 0
            or np.any(np.diff(x[:, 6]) != 1)
            or np.any(np.diff(x[:, 7]) <= 0)
            or not np.isin(x[:, 0], [-1, 0, 1]).all()
            or len(x) != original[f"{mode}/recording/{key}"]["scored_bins"]
        ):
            raise ValueError("incomplete, duplicated or invalid source chronology")
        group["values"] = x
    tasks = [
        (mode, [g for (m, _), g in groups.items() if m == mode], bundles[mode], config)
        for mode in bundles
    ]
    args.output.mkdir(parents=True, exist_ok=False)
    with ProcessPoolExecutor(max_workers=2) as pool:
        results = dict(pool.map(audit_mode, tasks))
    for mode, result in results.items():
        for policy in result["policies"]:
            if policy["persistence_bins"] == 1 and policy["cooldown_seconds"] == 0:
                name = "combined" if policy["head"] == "combined_or" else policy["head"]
                assert (
                    policy["pooled"]["normal_active_bins"]
                    == original[f"{mode}/all"][name]["normal_bin_alerts"]
                )
    report = dict(
        version=1,
        protocol=config,
        results=results,
        slurm_job_id=os.environ.get("SLURM_JOB_ID"),
        source_manifest=source_digest,
        checkpoint_hash=next(iter(bundles.values()))["checkpoint_hash"],
        calibration=bundles,
        scored_source_bins=sum(len(g["values"]) for g in groups.values()),
        input_sha256={
            str(p): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in (
                score_path,
                bundles_path,
                args.protocol,
                args.manifest,
                Path(__file__),
            )
        },
    )
    (args.output / "audit.json").write_text(json.dumps(report, indent=2) + "\n")
    print(
        f"Completed source-only audit: {report['scored_source_bins']} bins, {sum(len(r['policies']) for r in results.values())} policies",
        flush=True,
    )


if __name__ == "__main__":
    main()
