"""Evaluate frozen weights with real work on every torchrun rank; never fit.

Run with torchrun inside a multi-GPU Slurm allocation. Whole recording/mode
streams are assigned to ranks, including the disjoint calibration partition.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import time
from pathlib import Path
from types import SimpleNamespace

import torch

from graphids.core.data.snapshots.policy import ReferencePolicy
from graphids.core.models.graph_mamba import VehicleGraphMambaJoint
from graphids.core.models.score_columns import ScoreTable
from graphids.exp.config import ExperimentConfig
from graphids.exp.runtime import build_component


def traffic_rate_baseline(rows, attack_families, quantile=0.999):
    """Shared high-frame-rate baseline, calibrated only on source normal queries."""
    import numpy as np

    from graphids.core.models.score_columns import COL, ScoreBlock

    blocks = []
    for block in rows.blocks:
        values = block.values.copy()
        values[:, COL["classification"]] = np.divide(
            values[:, COL["events"]],
            values[:, COL["exposure"]],
            out=np.zeros(len(values)),
            where=values[:, COL["exposure"]] > 0,
        )
        blocks.append(ScoreBlock(block.identity, values))
    baseline = ScoreTable(blocks)
    bundles, thresholds = {}, {}
    for mode in ("zero-shot", "conditioned"):
        normal = (
            baseline.mode_mask(mode)
            & baseline.column("normal").astype(bool)
            & (baseline.identities["role"] == "val_query")
            & (baseline.column("label") == 0)
            & (baseline.column("exposure") > 0)
        )
        if not normal.any():
            raise ValueError("rate baseline requires verified-normal source validation")
        threshold = float(
            np.quantile(baseline.column("classification")[normal], quantile)
        )
        thresholds[mode] = threshold
        bundles[mode] = SimpleNamespace(
            mode=mode, thresholds=(threshold, None), available=(False, False, False)
        )
    report = baseline.report(
        bundles,
        classification=True,
        forecasting=False,
        partition="source",
        attack_families=attack_families,
    )
    report.update(
        baseline="events / exposure_seconds, high rate",
        units="frames_per_second",
        calibration="verified-normal source validation only",
        quantile=quantile,
        thresholds=thresholds,
        zero_exposure_score=0,
    )
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--checkpoint-sha256", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--partition", choices=("source", "target"), default="target")
    args = parser.parse_args()
    digest = hashlib.sha256(args.checkpoint.read_bytes()).hexdigest()
    if digest != args.checkpoint_sha256:
        raise ValueError("checkpoint changed after evaluation protocol was frozen")
    local_rank = int(os.environ["LOCAL_RANK"])
    torch.cuda.set_device(local_rank)
    torch.set_num_threads(2)
    torch.distributed.init_process_group(
        "nccl", device_id=torch.device("cuda", local_rank)
    )
    rank, world = torch.distributed.get_rank(), torch.distributed.get_world_size()
    root = args.output.resolve()
    os.environ["GRAPHIDS_RUN_DIR"] = str(root)
    try:
        if world < 2:
            raise ValueError("parallel evaluation requires at least two ranks")
        if rank == 0:
            root.mkdir(parents=True, exist_ok=False)
        torch.distributed.barrier()
        began = time.monotonic()
        cfg = ExperimentConfig.from_yaml(args.config)
        # Avoid worker startup overhead for this short, cached whole-recording pass.
        dm = build_component(dict(cfg.config["data"], num_workers=0, pin_memory=True))
        dm.setup()
        net = VehicleGraphMambaJoint.load_from_checkpoint(
            args.checkpoint, map_location="cpu"
        )
        if (
            net.hparams.backend != "official"
            or net.reference_policy != ReferencePolicy()
        ):
            raise ValueError(
                "this evaluation requires official CUDA and full conditioning"
            )
        net.prepare_from_datamodule(dm)
        net.to(local_rank).eval()
        source_bundles = {k: v.to_dict() for k, v in net.calibration_bundles.items()}
        calibration_hash = hashlib.sha256(
            json.dumps(source_bundles, sort_keys=True).encode()
        ).hexdigest()
        logs = {}
        net.log = lambda name, value, **kwargs: logs.__setitem__(name, float(value))
        net._trainer = SimpleNamespace(
            datamodule=dm, is_global_zero=rank == 0, default_root_dir=str(root)
        )
        with torch.inference_mode():
            net.on_test_epoch_start()  # validates frozen source calibration identity
            torch.cuda.synchronize()
            inference_started = time.monotonic()
            loaders = (
                [dm.val_dataloader()]
                if args.partition == "source"
                else dm.test_dataloader()
            )
            for loader_idx, loader in enumerate(loaders):
                for batch in loader:
                    net._evaluate(batch.to(local_rank), loader_idx, "test")
            torch.cuda.synchronize()
            local = ScoreTable(net._test_outputs)
            local.check_unique(f"rank-local {args.partition}")
            streams = sorted(
                set(zip(local.identities["recording"], local.identities["context"]))
            )
            stats = dict(
                rank=rank,
                device=torch.cuda.get_device_name(local_rank),
                scored_bins=len(local),
                streams=streams,
                inference_seconds=time.monotonic() - inference_started,
                calibration_sha256=calibration_hash,
                peak_allocated_bytes=torch.cuda.max_memory_allocated(local_rank),
            )
            all_stats = [None] * world
            torch.distributed.all_gather_object(all_stats, stats)
            if not all(s["scored_bins"] > 0 for s in all_stats):
                raise AssertionError(
                    f"every rank must perform actual {args.partition} inference"
                )
            owned = [tuple(stream) for s in all_stats for stream in s["streams"]]
            if len(owned) != len(set(owned)):
                raise AssertionError("recording/mode stream split across ranks")
            if len({s["calibration_sha256"] for s in all_stats}) != 1:
                raise AssertionError("ranks loaded different source calibration")
            if args.partition == "target":
                net.on_test_epoch_end()  # gathers, checks coverage, writes both tracks
            else:
                rows = net._gather_scores(net._test_outputs)
                if rows is not None:
                    rows.check_unique("source replay")
                    expected = set()
                    for key, start, stop, warmup, mode in dm.val_data.entries:
                        context = dm.context_for(key) if mode == "conditioned" else None
                        context_digest = context.digest if context else "zero-shot"
                        expected.update(
                            (key, context_digest, i)
                            for i in range(start + warmup, stop)
                        )
                    if set(rows.keys()) != expected:
                        raise ValueError("incomplete source replay coverage")
                    rows.apply_bundles(
                        net.calibration_bundles,
                        classification=net.hparams.classification,
                        forecasting=net.hparams.forecasting,
                    )
                    artifacts = root / "artifacts"
                    artifacts.mkdir(parents=True)
                    (artifacts / "metrics-v2.json").write_text(
                        json.dumps(
                            rows.report(
                                net.calibration_bundles,
                                partition="source",
                                attack_families=net.attack_families,
                                classification=net.hparams.classification,
                                forecasting=net.hparams.forecasting,
                            ),
                            indent=2,
                        )
                    )
                    (artifacts / "calibration-v2.json").write_text(
                        json.dumps(source_bundles, indent=2)
                    )
                    (artifacts / "coverage.json").write_text(
                        json.dumps(
                            dict(
                                scored_bins=len(rows),
                                expected_bins=len(expected),
                                missing_bins=0,
                                duplicate_bins=0,
                            ),
                            indent=2,
                        )
                    )
                    with (artifacts / "bin-scores.jsonl").open("w") as handle:
                        for row in rows:
                            handle.write(json.dumps(row) + "\n")
                    (artifacts / "traffic-rate-baseline.json").write_text(
                        json.dumps(
                            traffic_rate_baseline(rows, net.attack_families), indent=2
                        )
                    )
                    rows.log_metrics(net, "val")
        if source_bundles != {
            k: v.to_dict() for k, v in net.calibration_bundles.items()
        }:
            raise AssertionError("primary source calibration changed during evaluation")
        torch.distributed.barrier()
        if rank == 0:
            coverage = json.loads((root / "artifacts/coverage.json").read_text())
            assert sum(s["scored_bins"] for s in all_stats) == coverage["scored_bins"]
            report = dict(
                stage="complete",
                partition=args.partition,
                world_size=world,
                communication_environment={
                    name: os.environ.get(name)
                    for name in ("NCCL_P2P_DISABLE", "NCCL_IB_DISABLE")
                },
                ranks=all_stats,
                slurm_job_id=os.environ.get("SLURM_JOB_ID"),
                checkpoint_sha256=digest,
                reference_policy="full-reference",
                source_calibration_unchanged=True,
                calibration=source_bundles,
                coverage=coverage,
                wall_seconds=time.monotonic() - began,
                implementation_commit=subprocess.check_output(
                    ["git", "rev-parse", "HEAD"], text=True
                ).strip(),
                worktree_status=subprocess.check_output(
                    ["git", "status", "--porcelain"], text=True
                ),
                source_sha256={
                    str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                    for base in ("graphids", "scripts")
                    for p in sorted(Path(base).rglob("*.py"))
                },
                metrics=logs,
            )
            (root / "parallel-evaluation.json").write_text(
                json.dumps(report, indent=2) + "\n"
            )
            print(
                json.dumps(
                    {
                        k: report[k]
                        for k in (
                            "stage",
                            "world_size",
                            "ranks",
                            "coverage",
                            "wall_seconds",
                        )
                    },
                    indent=2,
                ),
                flush=True,
            )
    finally:
        torch.distributed.destroy_process_group()


if __name__ == "__main__":
    main()
