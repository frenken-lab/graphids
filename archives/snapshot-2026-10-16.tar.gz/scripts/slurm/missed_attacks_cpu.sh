#!/bin/bash
#SBATCH --clusters=pitzer
#SBATCH --account=pas1266
#SBATCH --cpus-per-task=8
#SBATCH --mem=96G
#SBATCH --time=02:00:00
#SBATCH --output=/fs/ess/PAS1266/graphids/dev/rf15/experimentruns/graph-mamba-missed-attacks-v1/cpu.log
set -euo pipefail
cd /users/PAS2022/rf15/projects/lab/graphids
module load python/3.12
export PYTHONPATH=$PWD PYTHONUNBUFFERED=1 OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2
.venv/bin/python -m pytest -q tests/test_missed_attacks.py
run=/fs/ess/PAS1266/graphids/dev/rf15/experimentruns/graph-mamba-multiattack-source-v1
out=/fs/ess/PAS1266/graphids/dev/rf15/experimentruns/graph-mamba-missed-attacks-v1
.venv/bin/python scripts/graph_mamba_missed_attacks.py audit --source-run "$run" --config "$run/experiment.yml" --checkpoint "$run/fit/checkpoints/best.ckpt" --output "$out"
