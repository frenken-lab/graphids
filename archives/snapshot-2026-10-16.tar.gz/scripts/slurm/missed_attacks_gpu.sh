#!/bin/bash
#SBATCH --clusters=ascend
#SBATCH --account=pas1266
#SBATCH --partition=nextgen
#SBATCH --gres=gpu:a100:2
#SBATCH --cpus-per-task=8
#SBATCH --mem=96G
#SBATCH --time=02:00:00
#SBATCH --output=/fs/ess/PAS1266/graphids/dev/rf15/experimentruns/graph-mamba-missed-attacks-v1/gpu.log
set -euo pipefail
cd /users/PAS2022/rf15/projects/lab/graphids
module purge
module load gcc/12.3.0 cuda/12.8.1
export PYTHONPATH=$PWD PYTHONUNBUFFERED=1 OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 NCCL_P2P_DISABLE=1 NCCL_IB_DISABLE=1
run=/fs/ess/PAS1266/graphids/dev/rf15/experimentruns/graph-mamba-multiattack-source-v1
out=/fs/ess/PAS1266/graphids/dev/rf15/experimentruns/graph-mamba-missed-attacks-v1
.venv/bin/python -m pytest -q tests/test_missed_attacks.py tests/core/models/test_graph_mamba.py tests/test_multiattack_review.py tests/core/data/test_snapshot_datamodule.py
.venv/bin/torchrun --standalone --nproc_per_node=2 scripts/graph_mamba_parallel_gate.py --mode native --output "$out/parallel-fixture"
.venv/bin/torchrun --standalone --nproc_per_node=2 scripts/graph_mamba_missed_attacks.py extract --source-run "$run" --config "$run/experiment.yml" --checkpoint "$run/fit/checkpoints/best.ckpt" --output "$out"
# The CPU allocation audits the same frozen source cohort concurrently.
.venv/bin/python - "$out/audit-status-0.json" <<'PY'
import json, sys, time
from pathlib import Path
p = Path(sys.argv[1])
for _ in range(120):
    if p.exists():
        status = json.loads(p.read_text())
        if status['status'] == 'complete':
            break
        if status['status'] == 'incomplete':
            raise RuntimeError(status)
    time.sleep(10)
else:
    raise TimeoutError('CPU audit not finished; extraction is retained')
PY
.venv/bin/torchrun --standalone --nproc_per_node=2 scripts/graph_mamba_missed_attacks.py probes --source-run "$run" --config "$run/experiment.yml" --checkpoint "$run/fit/checkpoints/best.ckpt" --output "$out"
.venv/bin/python scripts/graph_mamba_missed_attacks.py report --source-run "$run" --config "$run/experiment.yml" --checkpoint "$run/fit/checkpoints/best.ckpt" --output "$out"
