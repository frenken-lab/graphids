"""Source-only missed-attack diagnosis. Run substantial work in Slurm.

Stages are restartable at stage boundaries. Each recording/shard is persisted;
status files distinguish partial artifacts from completed stages.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import time
from collections import Counter, defaultdict
from dataclasses import asdict
from pathlib import Path

import numpy as np

from graphids.diagnostics.missed_attacks import (
    CHECKPOINT_SHA256,
    ByteTransitions,
    causal_messages,
    observed_idbins,
    physical_bins,
    source_manifest,
    write_json,
)


def slug(key):
    return key.replace("/", "__")


def setup(args):
    from graphids.exp.config import ExperimentConfig
    from graphids.exp.runtime import build_component

    cfg = ExperimentConfig.from_yaml(args.config)
    destination = args.output / "source-manifest.json"
    if not destination.exists():
        source_manifest(cfg.config["data"]["manifest_path"], destination)
    # Cache reads reuse frozen snapshots. Any cache misses go to a new sidecar cache.
    dm = build_component(
        dict(cfg.config["data"], manifest_path=str(destination), num_workers=0)
    )
    dm.setup()
    assert all(r.role.startswith(("train_", "val_")) for r in dm.records.values())
    return dm


def audit(args):
    from graphids.core.data.snapshots.manifest import file_hash, read_rows

    dm = setup(args)
    root = args.output / "audit"
    root.mkdir(parents=True, exist_ok=True)
    report = (
        json.loads((root / "audit.json").read_text())
        if (root / "audit.json").exists()
        else dict(recordings={}, target_evaluated=False, stages="running")
    )
    baseline = ByteTransitions().fit(
        read_rows(r)
        for r in dm.records.values()
        if r.role.startswith("train_")
        and r.verified_normal
        and r.payload_length_verified
    )
    # Sparse model persisted separately for reproducibility.
    import pickle

    with (root / "byte-transitions.pkl").open("wb") as f:
        pickle.dump(baseline, f)
    for rec in dm.records.values():
        if rec.key in report["recordings"]:
            continue
        began = time.monotonic()
        rows = read_rows(rec)
        bins = physical_bins([r["time"] for r in rows])
        context = dm.context_for(rec.key)
        snap = dm.snapshot_for(rec.key, context)
        profiles = (
            {key: context.profiles[i] for i, key in enumerate(context.anchor_ids)}
            if context
            else {}
        )
        x = causal_messages(rows, profiles, rec.payload_length_verified)
        ids = tuple(dict.fromkeys(r["id"] for r in rows))
        idmap = {k: i for i, k in enumerate(ids)}
        labels = np.array(
            [-1 if r["label"] is None else r["label"] for r in rows], np.int8
        )
        frame_ids = np.array([idmap[r["id"]] for r in rows], np.int32)
        by_idbin = observed_idbins(rows, bins)
        item = root / slug(rec.key)
        item.mkdir(exist_ok=True)
        transitions = baseline.score(rows)
        for start in range(0, len(rows), 65536):
            s = slice(start, start + 65536)
            np.savez(
                item / f"messages-{start:09d}.npz",
                x=x[s],
                label=labels[s],
                bin=bins[s],
                id=frame_ids[s],
                line=np.arange(start + 2, min(start + 65536, len(rows)) + 2),
                transition=transitions[s],
            )
        columns = {
            k: np.asarray([r[k] for r in by_idbin]) for k in by_idbin[0] if k != "id"
        }
        columns["id"] = np.array([idmap[r["id"]] for r in by_idbin], np.int32)
        np.savez(item / "idbins.npz", **columns)
        np.savez(
            item / "bins.npz",
            label=snap.labels,
            normal=snap.normal,
            exposure=snap.exposure,
            count=snap.event_count,
        )
        write_json(
            item / "identity.json",
            dict(recording=asdict(rec), family=dm.attack_families[rec.key], ids=ids),
        )
        repair = Path(rec.path).with_suffix(".clock.jsonl")
        if repair.exists():
            mappings = [json.loads(line) for line in repair.read_text().splitlines()]
            write_json(
                item / "clock-row-map.json",
                dict(
                    path=str(repair),
                    sha256=file_hash(repair),
                    moved_rows=mappings,
                    other_rows="original line equals derived line",
                ),
            )
        attack_ids = sorted({r["id"] for r in rows if r["label"] == 1})
        per_id = {}
        units_by_id, rows_by_id = defaultdict(list), defaultdict(list)
        for unit in by_idbin:
            if unit["label"] == 1:
                units_by_id[unit["id"]].append(unit)
        for row in rows:
            rows_by_id[row["id"]].append(row)
        snap_index = {key: i for i, key in enumerate(snap.ids)}
        for key in attack_ids:
            units = units_by_id[key]
            attack_payloads = {r["data"] for r in rows_by_id[key] if r["label"] == 1}
            legit_payloads = {r["data"] for r in rows_by_id[key] if r["label"] == 0}
            n = snap_index[key]
            selected = [u["bin"] for u in units]
            ci = (
                context.anchor_ids.index(key)
                if context and key in context.anchor_ids
                else None
            )
            neighbors = (
                []
                if ci is None
                else [
                    dict(
                        id=context.anchor_ids[int(j)],
                        features=context.edges[ci, slot].tolist(),
                    )
                    for slot, j in enumerate(context.neighbors[ci])
                    if context.edge_mask[ci, slot]
                ]
            )
            per_id[key] = dict(
                attacker_frames=sum(u["attacker_frames"] for u in units),
                positive_idbins=len(units),
                final_attacker=sum(u["final_attacker"] for u in units),
                attack_payload_survives=sum(
                    u["attack_payload_survives"] for u in units
                ),
                legitimate_overwrite_idbins=sum(
                    u["legitimate_after_attack"] > 0 for u in units
                ),
                mean_attacker_fraction=float(
                    np.mean([u["attacker_fraction"] for u in units])
                ),
                shared_payload_patterns=len(attack_payloads & legit_payloads),
                attacker_payload_patterns=len(attack_payloads),
                byte_valid_fraction=float(snap.features[selected, n, 12:20].mean())
                if selected
                else None,
                changed_positive_bins=int(snap.change[selected, n].sum()),
                mean_count=float(snap.counts[selected, n].mean()),
                mean_gap=float(snap.features[selected, n, 2].mean()),
                in_reference=ci is not None,
                neighbors=neighbors,
            )
        summary = dict(
            frames=len(rows),
            bins=len(snap.labels),
            positive_bins=int((snap.labels == 1).sum()),
            unknown_frames=int((labels < 0).sum()),
            unknown_bins=int((snap.labels < 0).sum()),
            unsupported_empty_bins=int((snap.event_count == 0).sum()),
            attacked_ids=per_id,
            transition_unavailable_frames=int(np.isnan(transitions).sum()),
            seconds=time.monotonic() - began,
        )
        report["recordings"][rec.key] = summary
        write_json(root / "audit.json", report)
        print("audit", rec.key, summary["frames"], flush=True)
    report["stages"] = "complete"
    write_json(root / "audit.json", report)
    exposure_audit(args, dm)


def exposure_audit(args, dm):
    result = []
    all_entries = dm.train_data.entries
    for epoch in range(10):
        dm.train_sampler.set_epoch(epoch)
        indices = dm.train_sampler.schedule()
        family = defaultdict(Counter)
        per_recording = Counter()
        for i in indices:
            key, start, stop, warmup, mode = all_entries[i]
            snap = dm.snapshot_for(key, None)
            labels = snap.labels[start + warmup : stop]
            c = family[dm.attack_families[key]]
            c.update(
                windows=1,
                positive_bins=int((labels == 1).sum()),
                known_bins=int((labels >= 0).sum()),
            )
            per_recording[key] += 1
        saved = json.loads(
            (args.source_run / f"fit/artifacts/training-work-{epoch}.json").read_text()
        )
        # Training artifacts gather work from both ranks; compare global exposure.
        observed = Counter(
            r for e in saved["sampled_episodes"] for r in e["recordings"]
        )
        expected = Counter(all_entries[i][0] for i in indices)
        saved_units = Counter(
            (e["recordings"][0], e["scored_bins"], e["scored_events"])
            for e in saved["sampled_episodes"]
        )
        scheduled_units = Counter()
        for i in indices:
            key, start, stop, warmup, mode = all_entries[i]
            snap = dm.snapshot_for(key, None)
            scheduled_units[
                key,
                stop - start - warmup,
                int(snap.event_count[start + warmup : stop].sum()),
            ] += 1
        if saved_units != scheduled_units:
            raise AssertionError(
                f"epoch {epoch}: saved bin/event signatures differ from reconstructed windows"
            )
        if observed != expected:
            raise AssertionError(
                f"epoch {epoch}: saved global work differs from reconstructed schedule"
            )
        result.append(
            dict(
                epoch=epoch,
                selected_windows=len(indices),
                omitted_windows=len(all_entries) - len(indices),
                selected_entry_indices=indices,
                omitted_entry_indices=sorted(
                    set(range(len(all_entries))) - set(indices)
                ),
                schedule_sha256=hashlib.sha256(
                    np.array(indices, np.int64).tobytes()
                ).hexdigest(),
                saved_global_work_matches=True,
                saved_recording_bin_event_signatures_match=True,
                saved_optimizer_steps=saved["optimizer_steps"],
                family=dict(family),
                recordings=dict(per_recording),
            )
        )
    write_json(args.output / "audit/training-exposure.json", result)
    curve = json.loads(
        (args.source_run / "fit/artifacts/learning-curve.json").read_text()
    )
    write_json(args.output / "audit/epoch-evidence.json", curve)


def extract(args):
    import torch

    from graphids.core.data.snapshots.batch import recording_batch
    from graphids.core.models.graph_mamba import VehicleGraphMambaJoint
    from graphids.core.models.score_columns import ScoreBlock

    if hashlib.sha256(args.checkpoint.read_bytes()).hexdigest() != CHECKPOINT_SHA256:
        raise ValueError("selected epoch-6 checkpoint SHA256 mismatch")
    rank, world = int(os.environ.get("RANK", 0)), int(os.environ.get("WORLD_SIZE", 1))
    if world != 2:
        raise ValueError("frozen extraction requires exactly two torchrun ranks")
    device = int(os.environ["LOCAL_RANK"])
    torch.cuda.set_device(device)
    torch.set_num_threads(2)
    torch.distributed.init_process_group("nccl", device_id=torch.device("cuda", device))
    dm = setup(args)
    net = VehicleGraphMambaJoint.load_from_checkpoint(
        args.checkpoint, map_location="cpu"
    )
    net.prepare_from_datamodule(dm)
    net.to(device).eval()
    net.on_test_epoch_start()  # validates frozen weights, source identity and calibration
    calibration = {k: v.to_dict() for k, v in net.calibration_bundles.items()}
    captured = {}

    def graph_hook(module, inputs, output):
        captured["nodes"] = output.detach()

    def classifier_hook(module, inputs):
        captured["pooled"] = inputs[0].detach()

    hooks = [
        net.graph.register_forward_hook(graph_hook),
        net.classifier.register_forward_pre_hook(classifier_hook),
    ]
    owned = []
    bins_scored = 0
    # Whole recordings, same deterministic ownership in serial fixture helper.
    queries = sorted(
        (r for r in dm.records.values() if r.role.endswith("query")),
        key=lambda r: r.key,
    )
    root = args.output / "embeddings"
    root.mkdir(exist_ok=True)
    if rank == 0:
        write_json(
            root / "coverage.json",
            dict(stage="running", checkpoint_sha256=CHECKPOINT_SHA256),
        )
    for rec in queries[rank::world]:
        folder = root / slug(rec.key)
        folder.mkdir(exist_ok=True)
        context = dm.context_for(rec.key)
        snap = dm.snapshot_for(rec.key, context)
        state = None
        with torch.inference_mode():
            for start in range(0, len(snap.labels), dm.eval_chunk_bins):
                stop = min(start + dm.eval_chunk_bins, len(snap.labels))
                batch = recording_batch(
                    snap,
                    context,
                    start=start,
                    stop=stop,
                    neighbor_cap=dm.neighbor_cap,
                    anchor_capacity=dm.anchor_capacity,
                    transient_capacity=dm.transient_capacity,
                ).to(device)
                prior = state.pending if state is not None else {}
                output, state = net.stream(batch, state)
                loss_sum, loss_count = streaming_loss_sums(net, batch, output, prior)
                nodes = captured["nodes"][0].cpu().numpy().astype(np.float16)
                pooled = captured["pooled"][0].cpu().numpy()
                block = ScoreBlock.from_batch(net, batch, output)
                ids = np.array(batch.node_keys[0])
                live = batch.live[0].cpu().numpy()
                observed = batch.counts[0].cpu().numpy() > 0
                np.savez(
                    folder / f"shard-{start:09d}.npz",
                    nodes=nodes,
                    pooled=pooled,
                    live=live,
                    observed=observed,
                    ids=ids,
                    bin=np.arange(start, stop),
                    labels=snap.labels[start:stop],
                    logits=output["classification_logits"][0].cpu().numpy(),
                    score_columns=block.values,
                    loss_sum=loss_sum,
                    loss_count=loss_count,
                )
                bins_scored += stop - start
        owned.append(
            dict(
                recording=rec.key,
                bins=len(snap.labels),
                shards=len(list(folder.glob("shard-*.npz"))),
            )
        )
        write_json(
            root / f"rank-{rank}-progress.json",
            dict(recordings=owned, bins=bins_scored),
        )
        print("extracted", rank, rec.key, len(snap.labels), flush=True)
    for hook in hooks:
        hook.remove()
    window_loss_audit(args, dm, net, device, rank, world)
    # Deterministic family-stratified windows, independent of validation performance.
    if rank == 0:
        gradient_audit(args, dm, net, device)
    assert calibration == {k: v.to_dict() for k, v in net.calibration_bundles.items()}
    stats = dict(
        rank=rank,
        device=torch.cuda.get_device_name(device),
        bins=bins_scored,
        recordings=owned,
        peak_bytes=torch.cuda.max_memory_allocated(device),
        calibration_unchanged=True,
    )
    gathered = [None] * world
    torch.distributed.all_gather_object(gathered, stats)
    if rank == 0:
        all_keys = [s["recording"] for r in gathered for s in r["recordings"]]
        assert len(all_keys) == len(set(all_keys)) and set(all_keys) == {
            r.key for r in queries
        }
        assert all(s["bins"] > 0 for s in gathered)
        expected = sum(len(dm.snapshot_for(r.key, None).labels) for r in queries)
        assert sum(s["bins"] for s in gathered) == expected
        write_json(
            root / "coverage.json",
            dict(
                stage="complete",
                ranks=gathered,
                expected_bins=expected,
                missing_bins=0,
                duplicate_bins=0,
                checkpoint_sha256=CHECKPOINT_SHA256,
                precision="node float16 sidecars; pooled/logits float32",
                target_evaluated=False,
            ),
        )
    torch.distributed.destroy_process_group()


def window_loss_audit(args, dm, net, device, rank, world):
    """Recompute selected-checkpoint losses using exact original window/context schedules."""
    import torch
    import torch.nn.functional as F

    net._distributed_mean = lambda values, mask: (
        (values * mask).sum() / mask.sum().clamp_min(1)
    )
    schedules = []
    for epoch in range(10):
        dm.train_sampler.set_epoch(epoch)
        schedules.append(dm.train_sampler.schedule())
    selected = sorted(set(i for schedule in schedules for i in schedule))
    results = {}
    with torch.inference_mode():
        for i in selected[rank::world]:
            batch = dm.train_data[i].to(device)
            output = net(batch)
            _, losses = net.losses(output, batch)
            cls = F.binary_cross_entropy_with_logits(
                output["classification_logits"],
                batch.labels.clamp_min(0).float(),
                reduction="none",
            )
            mask = batch.scored & (batch.labels >= 0)
            results[i] = dict(
                losses={k: float(v) for k, v in losses.items()},
                classification_positive_sum=float(
                    cls[mask & (batch.labels == 1)].sum()
                ),
                classification_negative_sum=float(
                    cls[mask & (batch.labels == 0)].sum()
                ),
                known_bins=int(mask.sum()),
                entry=dm.train_data.entries[i],
            )
            if len(results) % 100 == 0:
                write_json(
                    args.output / f"embeddings/window-losses-rank-{rank}.json",
                    dict(stage="running", windows=results),
                )
    write_json(
        args.output / f"embeddings/window-losses-rank-{rank}.json",
        dict(stage="complete", windows=results),
    )
    gathered = [None] * world
    torch.distributed.all_gather_object(gathered, results)
    if rank == 0:
        combined = {i: value for part in gathered for i, value in part.items()}
        assert len(combined) == len(selected) and sum(map(len, gathered)) == len(
            selected
        )
        epochs = []
        for epoch, schedule in enumerate(schedules):
            family = defaultdict(Counter)
            for i in schedule:
                rec = dm.records[dm.train_data.entries[i][0]]
                record = combined[i]
                item = family[dm.attack_families[rec.key]]
                item["windows"] += 1
                for k, value in record["losses"].items():
                    item[k + "_sum_of_window_means"] += value
                item["classification_positive_sum"] += record[
                    "classification_positive_sum"
                ]
                item["classification_negative_sum"] += record[
                    "classification_negative_sum"
                ]
                item["known_bins"] += record["known_bins"]
            epochs.append(dict(epoch=epoch, family=dict(family)))
        write_json(
            args.output / "embeddings/scheduled-loss-contributions.json",
            dict(
                stage="complete",
                epochs=epochs,
                evaluated_unique_windows=len(combined),
                scope="epoch-6 frozen checkpoint, eval-mode dropout, original source training episode boundaries/context modes; losses recomputed, not historical epoch losses",
            ),
        )


def distributed_loss_contributions(args, dm=None):
    """Attribute the globally reduced frozen objective using original rank pairs."""
    from graphids.diagnostics.missed_attacks import step_contributions

    dm = dm or setup(args)
    records = {}
    for rank in (0, 1):
        part = json.loads(
            (args.output / f"embeddings/window-losses-rank-{rank}.json").read_text()
        )
        if part["stage"] != "complete":
            raise ValueError("per-window frozen loss audit is incomplete")
        records.update({int(k): v for k, v in part["windows"].items()})
    components = ("classification", "count", "change", "new_id")
    windows = {}
    for index, item in records.items():
        key, start, stop, warmup, mode = item["entry"]
        rec = dm.records[key]
        denominators = dict.fromkeys(components, 0)
        denominators["classification"] = item["known_bins"]
        if rec.verified_normal:
            context = dm.context_for(key) if mode == "conditioned" else None
            snap = dm.snapshot_for(key, context)
            first = max(start + 1, start + warmup)
            eligible = snap.exposure[first:stop] > 0
            valid = (
                snap.live[first - 1 : stop - 1]
                & snap.live[first:stop]
                & (snap.generation[first - 1 : stop - 1] == snap.generation[first:stop])
            )
            valid &= eligible[:, None]
            denominators["count"] = int(valid.sum())
            denominators["change"] = int(
                (valid & snap.payload_observed[first:stop]).sum()
            )
            denominators["new_id"] = int(eligible.sum())
        numerators = {
            name: item["losses"][name] * denominators[name] for name in components
        }
        numerators["classification"] = (
            item["classification_positive_sum"] + item["classification_negative_sum"]
        )
        windows[index] = dict(
            family=dm.attack_families[key],
            numerators=numerators,
            denominators=denominators,
        )
    epochs = []
    for epoch in range(10):
        dm.train_sampler.set_epoch(epoch)
        schedule = dm.train_sampler.schedule()
        assert len(schedule) % 2 == 0
        family = defaultdict(Counter)
        for offset in range(0, len(schedule), 2):
            pair = [windows[i] for i in schedule[offset : offset + 2]]
            for name, values in step_contributions(pair).items():
                family[name].update(values)
        steps = len(schedule) // 2
        totals = {
            name: sum(values[name] for values in family.values()) for name in components
        }
        epochs.append(
            dict(
                epoch=epoch,
                optimizer_steps=steps,
                component_mean_per_step={
                    name: total / steps for name, total in totals.items()
                },
                family_contribution_sum={
                    name: dict(values) for name, values in family.items()
                },
                family_component_fraction={
                    name: {
                        c: values[c] / totals[c] if totals[c] else None
                        for c in components
                    }
                    for name, values in family.items()
                },
            )
        )
    write_json(
        args.output / "embeddings/distributed-loss-contributions.json",
        dict(
            stage="complete",
            epochs=epochs,
            scope="selected frozen checkpoint in eval mode; original paired-rank training schedules, globally summed masked denominators; per-window numerators reconstructed from retained means and source masks; tiny floating-point reconstruction error possible; not historical losses",
        ),
    )


def streaming_loss_sums(net, batch, output, prior):
    """Exact normal-only forecast objective sums including chunk boundaries."""
    import torch
    import torch.nn.functional as F

    labels = batch.labels[0]
    bce = F.binary_cross_entropy_with_logits(
        output["classification_logits"][0],
        labels.clamp_min(0).float(),
        reduction="none",
    )
    known = (labels >= 0) & batch.scored[0]
    rates, changes = torch.zeros_like(batch.counts), torch.zeros_like(batch.counts)
    matched = torch.zeros_like(batch.live)
    rates[:, 1:] = output["count_rate"][:, :-1]
    changes[:, 1:] = output["change_logits"][:, :-1]
    matched[:, 1:] = (
        batch.live[:, 1:]
        & batch.live[:, :-1]
        & (batch.generation[:, 1:] == batch.generation[:, :-1])
    )
    new_rate = torch.zeros_like(batch.exposure)
    new_rate[:, 1:] = output["new_id_rate"][:, :-1]
    if prior:
        new_rate[:, 0] = prior["new_id"]
        for i, key in enumerate(batch.node_keys[0]):
            identity = key, int(batch.generation[0, 0, i])
            j = prior["identities"].get(identity)
            if j is not None and bool(batch.live[0, 0, i]):
                rates[0, 0, i] = prior["count"][j]
                changes[0, 0, i] = prior["change"][j]
                matched[0, 0, i] = True
    # Normality is independently verified at recording level in this cohort;
    # unverified attack streams never contribute forecast training targets.
    eligible = batch.normal & batch.scored & (batch.exposure > 0)
    eligible[:, 0] &= bool(prior)
    matched &= eligible[..., None]
    payload = matched & batch.payload_observed
    count = net.poisson_surprise(rates, batch.counts, batch.exposure[..., None])
    change = F.binary_cross_entropy_with_logits(
        changes, batch.payload_change, reduction="none"
    )
    new = net.poisson_surprise(new_rate, batch.new_ids, batch.exposure)
    sums = torch.stack(
        (
            bce * known,
            (count * matched).sum(-1)[0],
            (change * payload).sum(-1)[0],
            (new * eligible)[0],
        ),
        -1,
    )
    counts = torch.stack(
        (known, matched.sum(-1)[0], payload.sum(-1)[0], eligible[0]), -1
    )
    return sums.cpu().numpy().astype(np.float64), counts.cpu().numpy().astype(np.int64)


def gradient_audit(args, dm, net, device):
    import torch

    # losses() all-reduces denominators; disable only this deterministic local
    # diagnostic by replacing the reducer, leaving the frozen model implementation intact.
    net._distributed_mean = lambda values, mask: (
        (values * mask).sum() / mask.sum().clamp_min(1)
    )
    chosen = {}
    for i, entry in enumerate(dm.train_data.entries):
        key, start, stop, warmup, mode = entry
        family = dm.attack_families[key]
        labels = dm.snapshot_for(key, None).labels[start + warmup : stop]
        if family not in chosen and ((labels == 1).any() or family == "normal"):
            chosen[family] = i
    result = {}
    shared = tuple(net.input_proj.parameters()) + tuple(net.temporal.parameters())
    for family, i in sorted(chosen.items()):
        batch = dm.train_data[i].to(device)
        _, losses = net.losses(net(batch), batch)
        record = dict(
            entry=dm.train_data.entries[i],
            losses={k: float(v.detach()) for k, v in losses.items()},
        )
        grads = {}
        for kind, loss in (
            ("classification", losses["classification"]),
            (
                "forecast",
                sum(
                    v * float((net.hparams.loss_weights or {}).get(k, 1))
                    for k, v in losses.items()
                    if k != "classification"
                ),
            ),
        ):
            g = torch.autograd.grad(loss, shared, retain_graph=True, allow_unused=True)
            grads[kind] = torch.cat(
                [
                    v.detach().flatten()
                    if v is not None
                    else torch.zeros_like(p).flatten()
                    for v, p in zip(g, shared, strict=True)
                ]
            )
            record[kind + "_gradient_l2"] = float(grads[kind].norm())
        record["gradient_cosine"] = float(
            torch.nn.functional.cosine_similarity(
                grads["classification"], grads["forecast"], dim=0
            )
        )
        result[family] = record
    write_json(
        args.output / "embeddings/gradients.json",
        dict(
            sample="first positive training window per family, ordered recording/cutoff; seed42 schedule config",
            family=result,
            scope="input projection and temporal blocks; eval mode; local production loss denominators",
        ),
    )


def probes(args):
    import torch

    from graphids.diagnostics.probes import fit_probe

    rank, world = int(os.environ.get("RANK", 0)), int(os.environ.get("WORLD_SIZE", 1))
    if rank == 0:
        import subprocess

        subprocess.run(
            [
                __import__("sys").executable,
                "-m",
                "pytest",
                "-q",
                "tests/test_missed_attacks.py",
            ],
            check=True,
        )
    device = int(os.environ.get("LOCAL_RANK", 0))
    torch.cuda.set_device(device)
    torch.set_num_threads(2)
    coverage_path = args.output / "embeddings/coverage.json"
    if (
        not coverage_path.exists()
        or json.loads(coverage_path.read_text()).get("stage") != "complete"
    ):
        raise ValueError("complete frozen extraction is required")
    sample = next((args.output / "embeddings").glob("*/shard-*.npz"))
    with np.load(sample) as z:
        needs_objective_sums = (
            "loss_sum" not in z
            or not (
                args.output / "embeddings/scheduled-loss-contributions.json"
            ).exists()
        )
    if needs_objective_sums:
        # Upgrade sidecars within this same two-A100 allocation after the
        # objective audit was added. Frozen checkpoint/calibration stay fixed.
        extract(args)
    kinds = ("pooled_bce", "pooled_balanced", "node_bin", "node_id", "message")
    for kind in kinds[rank::world]:
        fit_probe(args.output, kind, device)


def feature_evidence(args):
    dm = setup(args)
    exposure_audit(args, dm)
    distributed_loss_contributions(args, dm)
    result = {}
    for rec in dm.records.values():
        if not rec.role.endswith("query") or rec.verified_normal:
            continue
        context = dm.context_for(rec.key)
        snap = dm.snapshot_for(rec.key, context)
        with np.load(args.output / "audit" / slug(rec.key) / "idbins.npz") as units:
            identity = json.loads(
                (args.output / "audit" / slug(rec.key) / "identity.json").read_text()
            )
            mapping = np.array([snap.ids.index(ident) for ident in identity["ids"]])
            bins, nodes = units["bin"], mapping[units["id"]]
            feature = snap.features[bins, nodes]
            coverage = np.array(
                [
                    ident in context.anchor_ids if context else False
                    for ident in identity["ids"]
                ]
            )[units["id"]]
            positive = units["label"] == 1
            strata = {
                "overwritten": positive & ~units["attack_payload_survives"],
                "survives": positive & units["attack_payload_survives"],
                "in_reference": positive & coverage,
                "outside_reference": positive & ~coverage,
            }
            result[rec.key] = {}
            for name, selected in strata.items():
                if not selected.any():
                    continue
                x = feature[selected]
                result[rec.key][name] = dict(
                    idbins=int(selected.sum()),
                    mean_count=float(x[:, 0].mean()),
                    mean_gap=float(x[:, 2].mean()),
                    production_change_fraction=float(x[:, 3].mean()),
                    mean_payload_valid_bytes=float(x[:, 12:20].sum(1).mean()),
                )
            # Local current-ID feature collisions only; other nodes and temporal
            # history remain available and are explicitly outside this comparison.
            collision_ids = (
                np.unique(units["id"][positive])
                if dm.attack_families[rec.key] in ("gear_spoofing", "rpm_spoofing")
                else []
            )
            for ident in collision_ids:
                selected = (units["id"] == ident) & (units["label"] >= 0)
                _, inverse = np.unique(feature[selected], axis=0, return_inverse=True)
                bits = np.zeros(int(inverse.max()) + 1, np.uint8)
                np.bitwise_or.at(
                    bits, inverse, (1 << units["label"][selected]).astype(np.uint8)
                )
                result[rec.key][
                    "local_feature_collisions/" + identity["ids"][int(ident)]
                ] = dict(
                    feature_patterns_with_both_labels=int((bits == 3).sum()),
                    scope="current-bin same-ID canonical feature vector only; excludes other IDs, reference context and all history; no whole-model indistinguishability claim",
                )
    write_json(args.output / "audit/feature-evidence.json", result)


def reference_evidence(args, data):
    import pickle

    with (args.output / "audit/byte-transitions.pkl").open("rb") as f:
        baseline = pickle.load(f)
    per_id = defaultdict(dict)
    for (ident, byte), counts in baseline.marginal.items():
        p = counts[counts > 0] / counts.sum()
        transitions = [
            (previous, c)
            for (key, j, previous), c in baseline.transitions.items()
            if key == ident and j == byte
        ]
        total = sum(int(c.sum()) for _, c in transitions)
        per_id[ident][str(byte)] = dict(
            observed_values=int((counts > 0).sum()),
            marginal_entropy=float(-(p * np.log(p)).sum()),
            observations=int(counts.sum()),
            transition_contexts=len(transitions),
            unchanged_fraction=sum(int(c[previous]) for previous, c in transitions)
            / max(1, total),
        )
    novelty = {}
    report = dict(normal_source_training_byte_profiles=dict(per_id), query={})
    for key, meta in data.records.items():
        with np.load(args.output / "audit" / key / "bins.npz") as b:
            positive_novel = np.zeros(len(b["label"]), bool)
            positive_known_value = np.zeros_like(positive_novel)
        unavailable_ids = set()
        frame_counts = Counter()
        attacker_payloads = Counter()
        for path in sorted((args.output / "audit" / key).glob("messages-*.npz")):
            with np.load(path) as z:
                novel, available = (
                    np.zeros(len(z["label"]), bool),
                    np.zeros(len(z["label"]), bool),
                )
                values = np.rint(z["x"][:, :8] * 255).astype(np.int64)
                masks = z["x"][:, 8:16] > 0
                for i in np.unique(z["id"]):
                    ident = meta["ids"][int(i)]
                    selected = z["id"] == i
                    if meta["family"] in ("gear_spoofing", "rpm_spoofing"):
                        positive_frames = selected & (z["label"] == 1)
                        packed = np.concatenate(
                            (values[positive_frames], masks[positive_frames]), axis=1
                        )
                        patterns, counts = np.unique(packed, axis=0, return_counts=True)
                        for pattern, count in zip(patterns, counts, strict=True):
                            payload = bytes(
                                pattern[:8][pattern[8:].astype(bool)].astype(np.uint8)
                            ).hex()
                            attacker_payloads[ident + ":" + payload] += int(count)
                    for j in range(8):
                        counts = baseline.marginal.get((ident, j))
                        if counts is None:
                            if (selected & masks[:, j]).any() and not any(
                                (ident, byte) in baseline.marginal for byte in range(8)
                            ):
                                unavailable_ids.add(ident)
                            continue
                        valid = selected & masks[:, j]
                        available |= valid
                        novel[valid] |= counts[values[valid, j]] == 0
                pos = z["label"] == 1
                np.logical_or.at(positive_novel, z["bin"], pos & novel & available)
                np.logical_or.at(
                    positive_known_value, z["bin"], pos & ~novel & available
                )
                frame_counts.update(
                    positive_frames=int(pos.sum()),
                    positive_frames_with_novel_byte=int(
                        (pos & novel & available).sum()
                    ),
                    positive_frames_with_normal_byte_support=int(
                        (pos & ~novel & available).sum()
                    ),
                    unavailable_frames=int((~available).sum()),
                )
        report["query"][key] = dict(
            frame_counts=frame_counts,
            attacker_payload_patterns=dict(attacker_payloads),
            unavailable_ids=sorted(unavailable_ids),
            novelty_definition="at least one current valid byte value unseen for that ID/byte in verified-normal source training; marginal support is not joint payload support",
        )
        novelty[key] = positive_novel, positive_known_value
    write_json(args.output / "audit/normal-byte-evidence.json", report)
    payload_pattern_support(args, report)
    return novelty


def payload_pattern_support(args, byte_evidence):
    patterns = {
        pattern
        for item in byte_evidence["query"].values()
        for pattern in item["attacker_payload_patterns"]
    }
    result = {pattern: {} for pattern in sorted(patterns)}
    for identity in sorted((args.output / "audit").glob("*/identity.json")):
        meta = json.loads(identity.read_text())
        relevant = []
        for pattern in result:
            ident, payload = pattern.split(":")
            if ident in meta["ids"]:
                raw = bytes.fromhex(payload)
                values, mask = np.zeros(8, np.float32), np.zeros(8, np.float32)
                values[: len(raw)] = np.frombuffer(raw, np.uint8) / 255
                mask[: len(raw)] = 1
                relevant.append((pattern, meta["ids"].index(ident), values, mask))
        counts = defaultdict(Counter)
        for path in sorted(identity.parent.glob("messages-*.npz")):
            if not relevant:
                break
            with np.load(path) as z:
                x, ids, labels = z["x"], z["id"], z["label"]
                for pattern, ident, values, mask in relevant:
                    selected = np.flatnonzero(ids == ident)
                    matches = (x[selected, :8] == values).all(1) & (
                        x[selected, 8:16] == mask
                    ).all(1)
                    matched = labels[selected[matches]]
                    for label in (-1, 0, 1):
                        counts[pattern][str(label)] += int((matched == label).sum())
        for pattern, values in counts.items():
            if sum(values.values()):
                result[pattern][meta["recording"]["key"]] = dict(
                    labels=dict(values),
                    role=meta["recording"]["role"],
                    vehicle=meta["recording"]["vehicle"],
                    capture_group=meta["recording"]["session"],
                    verified_normal=meta["recording"]["verified_normal"],
                )
    write_json(
        args.output / "audit/payload-pattern-support.json",
        dict(
            patterns=result,
            scope="exact current same-ID payload bytes and validity only, across all 25 source recordings; excludes history, timing, other IDs and reference context; overlap is not whole-model indistinguishability",
        ),
    )


def verify_saved_scores(args, data):
    from graphids.core.models.calibration import CalibrationBundle
    from graphids.core.models.score_columns import COL

    bundle = CalibrationBundle(
        **json.loads(
            (
                args.source_run / "selected-source-eval/artifacts/calibration-v2.json"
            ).read_text()
        )["conditioned"]
    )

    predictions = {}
    for key, meta in data.records.items():
        if meta["recording"]["role"] != "val_query":
            continue
        parts = []
        for path in sorted((args.output / "embeddings" / key).glob("shard-*.npz")):
            with np.load(path) as z:
                columns = z["score_columns"]
                columns[:, COL["anomaly"]] = bundle.scores(
                    columns[:, 5:8], columns[:, 8:11]
                )
                parts.append(columns[:, [COL["classification"], COL["anomaly"]]])
        predictions[meta["recording"]["key"]] = np.concatenate(parts)
    seen = {key: np.zeros(len(v), bool) for key, v in predictions.items()}
    errors = np.zeros(2)
    retained = {
        key: dict(scores=np.zeros_like(value), eligible=np.zeros(len(value), bool))
        for key, value in predictions.items()
    }
    saved = args.source_run / "selected-source-eval/artifacts/bin-scores.jsonl"
    with saved.open() as f:
        for line in f:
            row = json.loads(line)
            if row["context"] == "zero-shot":
                continue
            key, b = row["recording"], row["bin"]
            if key not in predictions or seen[key][b]:
                raise AssertionError("saved-score duplicate or unexpected recording")
            seen[key][b] = True
            actual = predictions[key][b]
            expected = np.array([row["classification"], row["anomaly"]])
            retained[key]["scores"][b] = expected
            retained[key]["eligible"][b] = row["anomaly_eligible"]
            errors = np.maximum(errors, np.abs(actual - expected))
            np.testing.assert_allclose(actual, expected, rtol=2e-4, atol=2e-5)
    assert all(v.all() for v in seen.values())
    write_json(
        args.output / "embeddings/saved-score-parity.json",
        dict(
            conditioned_bins=sum(len(v) for v in seen.values()),
            exact_coverage=True,
            maximum_absolute_error=errors.tolist(),
            saved_scores_sha256=hashlib.sha256(saved.read_bytes()).hexdigest(),
        ),
    )
    return retained


def report(args):
    from graphids.core.models.score_columns import COL
    from graphids.diagnostics.missed_attacks import (
        metrics,
        normal_budgets,
    )
    from graphids.diagnostics.probes import ProbeData, collect_predictions

    data = ProbeData(args.output)
    saved_replay = verify_saved_scores(args, data)
    feature_evidence(args)
    novelty = reference_evidence(args, data)
    from graphids.core.models.calibration import CalibrationBundle

    frozen_bundle = CalibrationBundle(
        **json.loads(
            (
                args.source_run / "selected-source-eval/artifacts/calibration-v2.json"
            ).read_text()
        )["conditioned"]
    )
    result = dict(
        target_evaluated=False,
        independent_generalization=False,
        threshold_tracks="existing calibration unchanged; probes fixed .5; empirical normal budgets diagnostic only",
        frozen_score_track="retained selected-source validation scores; training forecast scores use the same frozen bundle in float64, matching saved evaluator arithmetic",
        prediction_targets="frame attribution and observed ID-bin attribution use origin labels; anomaly evidence is a separate comparison, not validated operational labels",
        silence="message/transition probes unsupported in empty bins; bus score zero",
        probes={},
        frozen_losses={},
    )
    kinds = [
        k
        for k in ("pooled_bce", "pooled_balanced", "node_bin", "node_id", "message")
        if (args.output / "probes" / k / "coverage.json").exists()
    ]
    from graphids.diagnostics.probes import verify_prediction_coverage

    for kind in kinds:
        verify_prediction_coverage(args.output, kind, data)
    for kind in ["frozen_classification", "frozen_forecast", "byte_transition", *kinds]:
        entries = []
        native = {}
        native_values = {}
        localization_values = {}
        losses = defaultdict(
            lambda: dict(
                classification_sum=0.0,
                known_bins=0,
                positive_classification_sum=0.0,
                negative_classification_sum=0.0,
                forecast_component_sum=[0.0, 0.0, 0.0],
                forecast_bins=[0, 0, 0],
                objective_sums=[0.0, 0.0, 0.0, 0.0],
                objective_counts=[0, 0, 0, 0],
            )
        )
        for key, meta in data.records.items():
            bins_path = args.output / "audit" / key / "bins.npz"
            with np.load(bins_path) as z:
                label, normal, exposure = z["label"], z["normal"], z["exposure"]
                observed = z["count"] > 0
            if kind.startswith("frozen"):
                score = np.zeros(len(label), np.float64)
                for p in sorted((args.output / "embeddings" / key).glob("shard-*.npz")):
                    with np.load(p) as z:
                        columns = z["score_columns"]
                        columns[:, COL["anomaly"]] = frozen_bundle.scores(
                            columns[:, 5:8], columns[:, 8:11]
                        )
                        idx = z["bin"]
                        score[idx] = columns[
                            :,
                            COL[
                                "classification"
                                if kind == "frozen_classification"
                                else "anomaly"
                            ],
                        ]
                        retained = saved_replay.get(meta["recording"]["key"])
                        if retained is not None:
                            score[idx] = retained["scores"][
                                idx, 0 if kind == "frozen_classification" else 1
                            ]
                        if kind == "frozen_forecast":
                            score[
                                idx[~columns[:, COL["anomaly_eligible"]].astype(bool)]
                            ] = np.nan
                        if kind == "frozen_classification":
                            l = z["labels"]
                            bce = (
                                np.logaddexp(0, z["logits"].astype(np.float64))
                                - np.maximum(l, 0) * z["logits"]
                            )
                            item = losses[
                                meta["recording"]["role"] + "/" + meta["family"]
                            ]
                            item["objective_sums"] = (
                                np.array(item["objective_sums"]) + z["loss_sum"].sum(0)
                            ).tolist()
                            item["objective_counts"] = (
                                np.array(item["objective_counts"])
                                + z["loss_count"].sum(0)
                            ).tolist()
                            item["known_bins"] += int((l >= 0).sum())
                            item["classification_sum"] += float(bce[l >= 0].sum())
                            item["positive_classification_sum"] += float(
                                bce[l == 1].sum()
                            )
                            item["negative_classification_sum"] += float(
                                bce[l == 0].sum()
                            )
                            for c in range(3):
                                eligible = columns[:, COL[f"mask{c}"]].astype(
                                    bool
                                ) & columns[:, COL["normal"]].astype(bool)
                                item["forecast_component_sum"][c] += float(
                                    columns[eligible, COL[f"component{c}"]].sum()
                                )
                                item["forecast_bins"][c] += int(eligible.sum())
                calibration = json.loads(
                    (
                        args.source_run
                        / "selected-source-eval/artifacts/calibration-v2.json"
                    ).read_text()
                )["conditioned"]
                threshold = calibration["thresholds"][
                    0 if kind == "frozen_classification" else 1
                ]
                threshold = (
                    float(threshold)
                    if threshold is not None
                    else float(np.finfo(np.float64).max)
                )
            elif kind == "byte_transition":
                score = np.zeros(len(label), np.float64)
                frame_scores, frame_labels, frame_bins, frame_ids = [], [], [], []
                unavailable = 0
                for p in sorted((args.output / "audit" / key).glob("messages-*.npz")):
                    with np.load(p) as z:
                        valid = np.isfinite(z["transition"])
                        np.maximum.at(score, z["bin"][valid], z["transition"][valid])
                        frame_scores.append(z["transition"])
                        frame_labels.append(z["label"])
                        frame_bins.append(z["bin"])
                        frame_ids.append(z["id"])
                        unavailable += int((~valid).sum())
                native_values[key] = (
                    np.concatenate(frame_scores),
                    np.concatenate(frame_labels),
                )
                from graphids.diagnostics.missed_attacks import aggregate_idbins

                # Unavailable baseline frames cannot supply a native ID score.
                finite = np.isfinite(native_values[key][0])
                localization_values[key] = aggregate_idbins(
                    native_values[key][0][finite],
                    native_values[key][1][finite],
                    np.concatenate(frame_bins)[finite],
                    np.concatenate(frame_ids)[finite],
                )
                native[key] = dict(
                    frame=metrics(*native_values[key], threshold=5.545177444479562),
                    unavailable_frames=unavailable,
                )
                threshold = (
                    5.545177444479562  # -log(1/256), predeclared uniform-byte surprise
                )
            else:
                score, values, idunits = collect_predictions(
                    args.output, kind, key, len(label)
                )
                native_values[key] = (values["score"], values["label"])
                native[key] = dict(native=metrics(values["score"], values["label"]))
                if idunits is not None:
                    localization_values[key] = idunits
                    native[key]["observed_idbin"] = metrics(*idunits)
                threshold = 0.5
            entries.append(
                dict(
                    key=key,
                    meta=meta,
                    scores=score,
                    labels=label,
                    normal=normal,
                    exposure=exposure,
                    observed=observed,
                    threshold=threshold,
                )
            )
        track = dict(
            native_by_recording=native,
            native={},
            localization={},
            bus={},
            stratified_misses={},
        )
        for role in ("train_query", "val_query"):
            role_entries = [
                e for e in entries if e["meta"]["recording"]["role"] == role
            ]
            if not role_entries:
                continue
            pooled_arrays = [
                np.concatenate([e[k] for e in role_entries])
                for k in ("scores", "labels", "normal", "exposure")
            ]
            pooled_valid = np.isfinite(pooled_arrays[0])
            pooled_budgets = normal_budgets(*(v[pooled_valid] for v in pooled_arrays))
            families = sorted(
                {
                    e["meta"]["family"]
                    for e in role_entries
                    if e["meta"]["family"] != "normal"
                }
            )
            for family in ["all", *families]:
                relevant = [
                    e
                    for e in role_entries
                    if family == "all" or e["meta"]["family"] in (family, "normal")
                ]
                vehicles = sorted(
                    {
                        e["meta"]["recording"]["vehicle"]
                        for e in relevant
                        if family == "all" or e["meta"]["family"] == family
                    }
                )
                for vehicle in ["pooled", *vehicles]:
                    selected = [
                        e
                        for e in relevant
                        if (
                            vehicle == "pooled"
                            and e["meta"]["recording"]["vehicle"] in vehicles
                        )
                        or e["meta"]["recording"]["vehicle"] == vehicle
                    ]
                    if not selected:
                        continue
                    scores, labels, normal, exposure = [
                        np.concatenate([e[k] for e in selected])
                        for k in ("scores", "labels", "normal", "exposure")
                    ]
                    valid = np.isfinite(scores)
                    name = f"{role}/{family}/{vehicle}"
                    budgets = {}
                    for budget, global_budget in pooled_budgets.items():
                        if budget == "unavailable":
                            continue
                        threshold = global_budget["threshold"]
                        m = metrics(scores, labels, threshold)
                        normal_mask = valid & normal & (labels == 0)
                        hours = float(exposure[normal_mask].sum() / 3600)
                        fp = int(
                            (scores[normal_mask].astype(np.float64) >= threshold).sum()
                        )
                        budgets[budget] = dict(
                            threshold=threshold,
                            recall=m["recall"],
                            false_bins=fp,
                            achieved_per_hour=fp / hours if hours else None,
                            pooled_normal=global_budget,
                        )
                    if native_values:
                        native_scores = np.concatenate(
                            [native_values[e["key"]][0] for e in selected]
                        )
                        native_labels = np.concatenate(
                            [native_values[e["key"]][1] for e in selected]
                        )
                        track["native"][name] = dict(
                            metrics=metrics(
                                native_scores, native_labels, selected[0]["threshold"]
                            ),
                            unit="frame"
                            if kind in ("message", "byte_transition")
                            else "observed_ID_bin"
                            if kind.startswith("node")
                            else "bus_bin",
                            capture_groups=len(
                                {e["meta"]["recording"]["session"] for e in selected}
                            ),
                        )
                    if localization_values:
                        localization_scores = np.concatenate(
                            [localization_values[e["key"]][0] for e in selected]
                        )
                        localization_labels = np.concatenate(
                            [localization_values[e["key"]][1] for e in selected]
                        )
                        track["localization"][name] = metrics(
                            localization_scores,
                            localization_labels,
                            selected[0]["threshold"],
                        )
                    track["bus"][name] = dict(
                        fixed=metrics(scores, labels, selected[0]["threshold"]),
                        normal_budgets=budgets,
                        capture_groups=len(
                            {e["meta"]["recording"]["session"] for e in selected}
                        ),
                        recordings=len(selected),
                        unsupported_empty_bins=sum(
                            int((~e["observed"]).sum()) for e in selected
                        )
                        if kind in ("message", "byte_transition")
                        else 0,
                    )
        # Join positive observed-ID bins to per-bin frozen/probe scores.
        for e in entries:
            if e["meta"]["recording"]["role"] != "val_query":
                continue
            with np.load(args.output / "audit" / e["key"] / "idbins.npz") as units:
                positive = units["label"] == 1
                audit_meta = json.loads((args.output / "audit/audit.json").read_text())[
                    "recordings"
                ][e["meta"]["recording"]["key"]]["attacked_ids"]
                reference = np.array(
                    [
                        audit_meta.get(ident, {}).get("in_reference", False)
                        for ident in e["meta"]["ids"]
                    ]
                )[units["id"]]
                strata = {
                    "in_reference": positive & reference,
                    "outside_reference": positive & ~reference,
                    "payload_overwritten": positive & ~units["attack_payload_survives"],
                    "payload_survives": positive & units["attack_payload_survives"],
                    "injection_fraction_le_0.25": positive
                    & (units["attacker_fraction"] <= 0.25),
                    "injection_fraction_gt_0.25": positive
                    & (units["attacker_fraction"] > 0.25),
                    "novel_byte_in_positive_bin": positive
                    & novelty[e["key"]][0][units["bin"]],
                    "normal_supported_bytes_in_positive_bin": positive
                    & novelty[e["key"]][1][units["bin"]],
                }
                for i, ident in enumerate(e["meta"]["ids"]):
                    strata["id/" + ident] = positive & (units["id"] == i)
                track["stratified_misses"][e["key"]] = {
                    name: dict(
                        idbins=int(mask.sum()),
                        recalled_idbins=int(
                            (e["scores"][units["bin"][mask]] >= e["threshold"]).sum()
                        ),
                    )
                    for name, mask in strata.items()
                    if mask.any()
                }
        result["probes"][kind] = track
        if kind == "frozen_classification":
            result["frozen_losses"] = dict(
                scope="continuous conditioned streaming objective sums/counts including chunk boundaries, train/validation separate; per-bin max forecast surprises are separate from objective means; not original finite training episode state",
                values=dict(losses),
            )
        write_json(args.output / "results.json", result)
    render_report(args, result, kinds)


def render_report(args, result, kinds):
    """Render completed machine results without replaying data or fitting models."""
    recommendation = []
    comparisons = [
        (
            "message",
            "node_id",
            "investigate preserving/scoring messages; representation, supervision and head capacity change together",
        ),
        (
            "pooled_balanced",
            "pooled_bce",
            "address classification balance while retaining snapshot inputs",
        ),
        (
            "node_bin",
            "pooled_balanced",
            "investigate per-ID scoring and max aggregation",
        ),
        ("node_id", "node_bin", "add explicit localization targets"),
        (
            "byte_transition",
            "frozen_forecast",
            "investigate payload-value/distribution forecasting",
        ),
    ]
    for family in ("gear_spoofing", "rpm_spoofing"):
        findings = []
        name = f"val_query/{family}/pooled"
        for candidate, baseline, direction in comparisons:
            if candidate not in result["probes"] or baseline not in result["probes"]:
                continue
            a = (
                result["probes"][candidate]["bus"]
                .get(name, {})
                .get("fixed", {})
                .get("ap")
            )
            b = (
                result["probes"][baseline]["bus"]
                .get(name, {})
                .get("fixed", {})
                .get("ap")
            )
            if a is not None and b is not None:
                findings.append(
                    dict(
                        candidate=candidate,
                        comparator=baseline,
                        ap_delta=a - b,
                        supported_direction=direction
                        if a - b >= 0.05
                        else "no material AP gain under the descriptive 0.05 criterion",
                    )
                )
        recommendation.append(dict(family=family, comparisons=findings))
    result["recommendation"] = dict(
        status="exploratory; inspect false-bin budgets and vehicle disagreement alongside AP",
        family=recommendation,
        attribution="do not infer authenticity impossibility from shared payloads or current-bin features; history and other IDs remain accessible",
        anomaly="normal-only transition surprise supports an anomaly target, not attacker-origin equivalence",
        message="message versus snapshot comparisons change both representation and supervision; overwrite-stratum gains support preserving individual messages but do not isolate one cause",
    )
    result["recommendation"]["next_direction"] = (
        "mixed; investigate message-preserving local anomaly scoring and normal-only payload-value distributions alongside the existing pooled classifier/count-change heads; RPM frame-origin attribution remains unresolved"
    )
    result["recommendation"]["native_target_check"] = {}
    for family in ("gear_spoofing", "rpm_spoofing"):
        key = f"val_query/{family}/pooled"
        track = result["probes"].get("message", {})
        frame = track.get("native", {}).get(key, {}).get("metrics")
        local = track.get("localization", {}).get(key)
        if frame and local:
            result["recommendation"]["native_target_check"][family] = dict(
                attacker_frame_tp=frame["tp"],
                attacker_frame_positive=frame["positive"],
                attacker_frame_ap=frame["ap"],
                observed_idbin_tp=local["tp"],
                observed_idbin_ap=local["ap"],
                threshold=0.5,
                interpretation="ID-bin gains need not identify attacker frames; origin-derived bin labels do not certify operational-state/incident detection",
            )
    write_json(args.output / "results.json", result)
    lines = [
        "# Source missed-attack diagnostic evidence",
        "",
        "Selected checkpoint: epoch 6, SHA256 `"
        + CHECKPOINT_SHA256
        + "`. No target evaluation or encoder retraining.",
        "",
        "Validation bus-bin comparisons (native-unit results, vehicles, counts, budgets and overwrite strata are in results.json):",
        "",
        "| Readout | Family | AP | Recall | F1 |",
        "|---|---|---:|---:|---:|",
    ]
    for kind, track in result["probes"].items():
        for name, item in track["bus"].items():
            role, family, vehicle = name.split("/")
            if role == "val_query" and vehicle == "pooled" and family != "all":
                m = item["fixed"]
                ap = f"{m['ap']:.4f}" if m["ap"] is not None else "unavailable"
                lines.append(
                    f"| {kind} | {family} | {ap} | {m['recall']:.4f} | {m['f1']:.4f} |"
                )
    lines += [
        "",
        "Native validation units for the payload probes (neural threshold 0.5; byte baseline log(256)):",
        "",
        "| Readout | Family | Unit | AP | Precision | Recall | F1 | Units | Positives |",
        "|---|---|---|---:|---:|---:|---:|---:|---:|",
    ]
    for kind in ("message", "byte_transition", "node_bin", "node_id"):
        if kind not in result["probes"]:
            continue
        track = result["probes"][kind]
        for family in ("gear_spoofing", "rpm_spoofing"):
            key = f"val_query/{family}/pooled"
            units = []
            if kind in ("message", "byte_transition") and key in track["native"]:
                units.append(("frame", track["native"][key]["metrics"]))
            if key in track["localization"]:
                units.append(("observed ID-bin", track["localization"][key]))
            for unit, metric in units:
                ap = (
                    f"{metric['ap']:.4f}" if metric["ap"] is not None else "unavailable"
                )
                lines.append(
                    f"| {kind} | {family} | {unit} | {ap} | {metric['precision']:.4f} | {metric['recall']:.4f} | {metric['f1']:.4f} | {metric['n']} | {metric['positive']} |"
                )
    rpm = (
        result["probes"]
        .get("message", {})
        .get("native", {})
        .get("val_query/rpm_spoofing/pooled", {})
        .get("metrics")
    )
    rpm_id = (
        result["probes"]
        .get("message", {})
        .get("localization", {})
        .get("val_query/rpm_spoofing/pooled")
    )
    if rpm and rpm_id:
        lines += [
            "",
            f"RPM target distinction: the message probe identifies {rpm['tp']} of {rpm['positive']} attacker frames at 0.5, while detecting {rpm_id['tp']} positive observed ID-bins. Bin gains from legitimate frames do not establish attacker-frame attribution. Presence-of-attacker bin labels are also not independently verified operational-state or incident labels.",
        ]
    lines += [
        "",
        "Evidence-based directions (AP deltas are descriptive, not significance tests):",
    ]
    for family in recommendation:
        for comparison in family["comparisons"]:
            lines.append(
                f"- {family['family']}: {comparison['candidate']} versus {comparison['comparator']}, AP delta {comparison['ap_delta']:+.4f}: {comparison['supported_direction']}."
            )
    lines += [
        "",
        "These are exploratory source comparisons. Fixed thresholds and diagnostic budget sweeps are separate. Frame and observed-ID labels describe attacker origin; operational anomaly detection lacks independently trusted incident intervals. No duration, incident recall or detection-delay claim is supported.",
        "",
        "A message-versus-snapshot difference changes both representation and supervision. Current-bin compression ambiguity does not establish indistinguishability with causal history. The byte-transition baseline measures value predictability; unavailable IDs are excluded from its native AP and reported separately.",
        "",
        "Recommendation: inspect the family/vehicle results and overwrite strata before another full fit. Treat improvements as exploratory. Keep classification and forecasting separate; do not promote a policy from pooled results alone.",
    ]
    (args.output / "evidence-report.md").write_text("\n".join(lines) + "\n")
    write_json(
        args.output / "report-coverage.json",
        dict(
            completed_probe_kinds=kinds,
            incomplete_probe_kinds=[
                k
                for k in (
                    "pooled_bce",
                    "pooled_balanced",
                    "node_bin",
                    "node_id",
                    "message",
                )
                if k not in kinds
            ],
        ),
    )


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("stage", choices=("audit", "extract", "probes", "report"))
    p.add_argument("--source-run", type=Path, required=True)
    p.add_argument("--config", type=Path, required=True)
    p.add_argument("--checkpoint", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    return p


def main():
    args = parser().parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    status = args.output / f"{args.stage}-status-{os.environ.get('RANK', '0')}.json"
    write_json(
        status,
        dict(
            stage=args.stage,
            status="running",
            slurm_job_id=os.environ.get("SLURM_JOB_ID"),
        ),
    )
    try:
        globals()[args.stage](args)
    except BaseException as exc:
        write_json(status, dict(stage=args.stage, status="incomplete", error=repr(exc)))
        raise
    write_json(
        status,
        dict(
            stage=args.stage,
            status="complete",
            slurm_job_id=os.environ.get("SLURM_JOB_ID"),
        ),
    )


if __name__ == "__main__":
    main()
