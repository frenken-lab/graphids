# Message-preserving graph–Mamba input

The next model path uses `can_event_dm` with `event_graph_mamba`. Every observed
CAN frame enters the temporal encoder in physical recording order. This follows
the requirement to preserve raw observations and let the model learn its own
representations. The older `can_snapshot_dm` / `vehicle_graph_mamba_joint` path
remains available to reproduce its checkpoints and diagnostic comparisons.

The new experiment is
`configs/experiments/graph_mamba_events_source.yml`. It is a separate architecture
and checkpoint identity; snapshot weights and calibration cannot be loaded into
it. Adding this path does not establish improved attack detection, and no full
encoder fit has been run as part of implementing it.

## Input contract

One event contains the numeric CAN arbitration ID, observed payload bytes,
payload length, and timestamp. The cache preserves all 29 ID bits, exact byte
values, FP64 physical timestamps, equal-timestamp row ordering, and every physical
CSV row, including duplicates and messages subsequently overwritten within the
same 10 ms interval. Source rows already subject to reviewed clock repair retain
their reviewed ordering; this path does not independently repair or sort clocks.
It does not reconstruct unavailable wire fields such as an absent IDE/RTR flag.

The neural input directly encodes the available frame fields:
eight byte values scaled by 255, eight byte-presence masks, 29 ID bits, length
scaled by eight, elapsed recording time, and the preceding bus interarrival time.
Elapsed time and interarrival are computed in FP64 and converted to the model's
usual floating point dtype at projection. Absolute clock origin is retained in
the cache but is not a learned recording-identity feature. There are no binned
counts, payload-change summaries, byte-difference heuristics, normal-reference
traffic profiles, or correlation-selected graph edges. Labels, normality flags,
recording names, roles, vehicles, and source interfaces do not enter the encoder.
Normality and payload provenance only control eligible training targets.

Chunks are execution units, not summaries. Every constituent event is encoded
and scored individually. During training, each frame is a scored target exactly
once per epoch; preceding warmup frames supply additional context and are masked
out of that window's loss. Training windows start with empty learned state and
have a bounded warmup, so they do not claim unlimited training history. Validation
and online `stream()` retain both Mamba caches and graph memory across chunks and
reset at recording boundaries. Unknown labels remain unknown and are excluded
from supervised loss.

## Learned temporal and graph context

A shared Mamba stack advances on the chronological **bus message sequence**. Its
output at each event therefore incorporates earlier messages from all observed
IDs. A graph readout uses learned query/key/value attention to the latest
*preceding* Mamba state for each encountered CAN ID. The current event's encoded
state queries those historical node states; its updated temporal state becomes
that ID's memory for subsequent events. Future IDs and future observations are
masked out. Attention learns relationships instead of receiving a graph chosen
from count/change correlations. This differs from the snapshot model's per-ID
clock-tick Mamba streams and its fixed reference-neighbor readout.

These hidden states are learned compression **after** individual messages enter
the network. Raw inputs are not replaced by a hand-selected per-bin payload.
Node and graph-work capacities fail explicitly when exceeded; they never evict
IDs, truncate messages, or merge events. This first version supports one training
or evaluation device. It rejects multi-device configurations rather than silently
padding evaluation or splitting a stream's chronological state across ranks.

## Prediction and learning targets

The supervised head predicts attacker-frame labels with BCE. A separate
normal-only head predicts eight categorical byte distributions from preceding
bus/per-ID states and the arriving frame's header/timing, before that frame's
payload can enter the predictor. Valid observed bytes from independently
verified-normal training recordings supply this objective. It is a simple
factorized byte likelihood, not a joint payload distribution or an operational
fault-state model. Source attack recordings do not train the normal-only loss.

Payload NLL is reported as an uncalibrated anomaly ranking. It does not reuse
snapshot calibration. Both scores remain distinct: an abnormal payload score is
not an assertion of attacker origin. No operational fault labels have been added.
An observed-frame interface has no prediction unit during complete silence;
absence/suppression detection will require a separately evaluated clock or
next-arrival survival objective. No such objective is implied by frame scores.

The preset retains the reviewed Impala/Silverado source split, filters out target
roles before opening data files, and uses neither target evaluation nor reference
summary features. Reference recordings remain reserved and are not used as query
training examples. Explicit source fitting is:

```bash
gx exp config configs/experiments/graph_mamba_events_source.yml
gx exp submit configs/experiments/graph_mamba_events_source.yml -C ascend
```

Do not interpret this preset as a controlled architecture ablation: event units,
temporal routing, graph construction, supervision granularity, normality targets,
and optimizer-step exposure differ from the snapshot experiment. A subsequent
learning experiment must report frame attribution and common bus-bin comparison
separately, fit calibration on source data only, and retain existing model results
as controls.

## Verification and artifacts

Run tests in Slurm, including `tests/test_event_graph_mamba.py`. They cover exact
payload and row preservation, timestamp ties, empty payloads, unknown labels,
source-only loading, warmup masks and exact scored coverage, future-perturbation
causality, current-payload exclusion from forecasting, arbitrary chunk boundaries,
state identity, capacity failures, checkpoint round trips, a Lightning learning
smoke test, and pinned official CUDA versus reference outputs and gradients.

For a complete source-ingestion audit, run in a CPU allocation:

```bash
python scripts/graph_mamba_event_input_audit.py \
  --output "$GRAPHIDS_RUN_ROOT/experimentruns/graph-mamba-events-source-v1/verification/source-input-audit.json"
```

This rereads every selected source query row and checks every cache field against
it, persisting per-record progress and hashes. Failed or interrupted work is
reported as incomplete. Model evaluation writes one bounded NPZ shard per chunk,
with physical row offsets and source identities, plus an index recording exact
coverage and frame-level AP. Incomplete validation is rejected. Thresholds and
snapshot calibration are not silently transferred to the new model.

Implementation verification on 2026-10-16 checked all **21,285,666 query frames
across 21 source recordings**, with every cached field matching its CSV row.
CPU regression job `56288831` passed 49 tests (two GPU-only cases skipped).
A100 job `7891355` passed 15 tests, including official/reference kernel parity;
final event-specific checks passed across jobs `7891363` and `7891364` (the latter
corrected a test that checked device placement after Lightning teardown instead
of during training). The complete ingestion audit is CPU job `56288850`.
Machine-readable verification, logs, and an implementation source archive are at
`/fs/ess/PAS1266/graphids/dev/rf15/experimentruns/graph-mamba-events-source-v1/verification/`.
These are correctness and small learning smoke checks, not a new detection result.
