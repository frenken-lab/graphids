# CAN events, snapshots and recording manifests

New learning work uses [message-preserving event inputs](../reference/graph-mamba-events.md)
through `can_event_dm`. The snapshot interface remains available for existing results.

Versioned recording manifests assign disjoint source and target roles, explicit
label/normality provenance, and content hashes. Snapshot caches preserve causal
features, empty bins and partial-bin exposure. Immutable vehicle context stores
reference profiles and bounded graph topology. Stream batching and distributed
schedules preserve recording-local state and expose scored work.

See [training and evaluation](../reference/graph-mamba.md).

::: graphids.core.data.snapshots.manifest

::: graphids.core.data.snapshots.datamodule

::: graphids.core.data.snapshots.online

::: graphids.primitives_data

::: graphids.core.data.events.data
