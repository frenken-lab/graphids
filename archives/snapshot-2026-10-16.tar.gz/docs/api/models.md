# Graph Mamba model

`event_graph_mamba` is the message-preserving learning primitive; see the
[event architecture](../reference/graph-mamba-events.md).
`vehicle_graph_mamba_joint` remains the snapshot comparison primitive. Its shared
parameters support varying local ID sets without learned raw-ID or vehicle
embeddings. Classification and next-bin forecasting share temporal Mamba and a
bounded graph readout; component scores remain separate.

See [training and evaluation](../reference/graph-mamba.md) for architecture,
causality, masks, and checkpoint migration.

::: graphids.core.models.graph_mamba

::: graphids.primitives_models

::: graphids.core.models.event_graph_mamba
