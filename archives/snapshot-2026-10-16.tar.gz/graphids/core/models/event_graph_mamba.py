"""Message-resolution Mamba and learned causal CAN-ID graph readout.

Every observed frame enters Mamba before any learned compression. Graph keys are
latest *preceding* per-ID temporal states, with learned attention rather than
count/change correlation edges. This is a separate, incompatible checkpoint type.
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from pathlib import Path

import lightning.pytorch as pl
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

from .mamba_chunk import mamba_chunk
from .score_columns import raw_average_precision


@dataclass
class EventGraphMambaState:
    recording: str = ""
    source_digest: str = ""
    next_row: int = 0
    last_timestamp: float = -math.inf
    caches: list = field(default_factory=list)
    ids: tuple[int, ...] = ()
    nodes: torch.Tensor | None = None
    previous_bus: torch.Tensor | None = None


class EventGraphMamba(pl.LightningModule):
    def __init__(
        self,
        *,
        width=128,
        layers=2,
        d_state=16,
        d_conv=4,
        expand=2,
        dropout=0.1,
        backend="official",
        learning_rate=1e-3,
        weight_decay=0.01,
        payload_weight=1.0,
        node_capacity=512,
        max_graph_tokens=1048576,
        schema_version=1,
    ):
        super().__init__()
        if backend not in ("official", "reference") or schema_version != 1:
            raise ValueError("unsupported event Graph-Mamba backend/schema")
        if (
            min(width, layers, d_state, d_conv, expand, node_capacity, max_graph_tokens)
            < 1
        ):
            raise ValueError("positive event model dimensions/capacities required")
        if (
            not 0 <= dropout < 1
            or not math.isfinite(payload_weight)
            or payload_weight < 0
        ):
            raise ValueError("invalid event dropout/payload loss weight")
        self.save_hyperparameters()
        # Exact frame fields encoded numerically: bytes, byte-presence masks,
        # all 29 ID bits, byte length, elapsed time, preceding interarrival time.
        self.input_proj = nn.Linear(48, width)
        self.norms = nn.ModuleList(nn.LayerNorm(width) for _ in range(layers))
        if backend == "official":
            from graphids.runtime_checks import assert_mamba_backend

            assert_mamba_backend()
            from mamba_ssm import Mamba

            self.temporal = nn.ModuleList(
                Mamba(
                    d_model=width,
                    d_state=d_state,
                    d_conv=d_conv,
                    expand=expand,
                    layer_idx=i,
                )
                for i in range(layers)
            )
        else:
            from .mamba_reference import ReferenceMamba

            self.temporal = nn.ModuleList(
                ReferenceMamba(width, d_state, d_conv, expand) for _ in range(layers)
            )
        self.dropout = nn.Dropout(dropout)
        self.query, self.key, self.value = (nn.Linear(width, width) for _ in range(3))
        self.graph_gate = nn.Linear(width * 2, width)
        self.graph_norm = nn.LayerNorm(width)
        self.classifier = nn.Linear(width, 1)
        # Header/current arrival are known; current payload is absent from every
        # path feeding this forecast. Predictions precede the frame-state update.
        self.payload_head = nn.Sequential(
            nn.Linear(width * 2 + 32, width), nn.SiLU(), nn.Linear(width, 8 * 256)
        )
        self._stream_state = None
        self._score_parts = []
        self._score_index = []
        self._source_manifest_digest = None

    def prepare_from_datamodule(self, dm):
        if getattr(dm.representation_cfg, "kind", None) != "can_event":
            raise ValueError("event_graph_mamba requires can_event_dm")
        digest = dm.manifest.digest
        if (
            self._source_manifest_digest is not None
            and self._source_manifest_digest != digest
        ):
            raise ValueError(
                "event checkpoint source manifest differs from current data"
            )
        self._source_manifest_digest = digest
        self._recordings = dm.records

    def fields(self, batch):
        bits = (
            (batch.ids[:, None] >> torch.arange(29, device=batch.ids.device)) & 1
        ).float()
        mask = torch.arange(8, device=batch.ids.device)[None] < batch.lengths[:, None]
        # Scaling is invertible for every byte and length; no message aggregates.
        header = torch.cat(
            (bits, batch.lengths[:, None].float() / 8, batch.times.float()), -1
        )
        return torch.cat(
            (batch.payload.float() / 255, mask.float(), header), -1
        ), header

    def _routing(self, batch, state):
        # CPU indices depend only on IDs encountered so far. Future slots have
        # a false mask and contribute neither keys nor normalization mass.
        ids = list(state.ids)
        mapping = {key: i for i, key in enumerate(ids)}
        current = []
        for key in batch.routing_ids:
            if key not in mapping:
                mapping[key] = len(ids)
                ids.append(key)
            current.append(mapping[key])
        n, t = len(ids), len(current)
        if n > self.hparams.node_capacity:
            raise ValueError(
                "event node capacity exceeded; no IDs were silently evicted"
            )
        if n * t > self.hparams.max_graph_tokens:
            raise ValueError("event graph capacity exceeded; use smaller event chunks")
        initial = np.full(n, -1, dtype=np.int64)
        initial[: len(state.ids)] = np.arange(len(state.ids))
        previous = np.empty((t, n), dtype=np.int64)
        own = np.empty(t, dtype=np.int64)
        offset = len(state.ids)
        for i, slot in enumerate(current):
            previous[i] = initial
            own[i] = initial[slot]
            initial[slot] = offset + i
        return tuple(ids), previous, own, initial

    def _readout(self, h, header, batch, state):
        ids, previous, own, final = self._routing(batch, state)
        past = state.nodes if state.nodes is not None else h.new_empty((0, h.shape[-1]))
        bank = torch.cat((past, h), 0)
        index = torch.as_tensor(previous, device=h.device)
        mask = index >= 0
        neighbors = bank[index.clamp_min(0)]
        logits = (self.query(h)[:, None] * self.key(neighbors)).sum(-1) / math.sqrt(
            h.shape[-1]
        )
        weights = logits.masked_fill(~mask, torch.finfo(logits.dtype).min).softmax(-1)
        weights = weights * mask
        aggregate = (weights[..., None] * self.value(neighbors)).sum(1)
        z = self.graph_norm(
            h
            + torch.sigmoid(self.graph_gate(torch.cat((h, aggregate), -1))) * aggregate
        )
        own_index = torch.as_tensor(own, device=h.device)
        previous_id = bank[own_index.clamp_min(0)] * (own_index >= 0)[:, None]
        preceding_bus = (
            state.previous_bus
            if state.previous_bus is not None
            else h.new_zeros(h.shape[-1])
        )
        previous_bus = torch.cat((preceding_bus[None], h[:-1]), 0)
        payload_logits = self.payload_head(
            torch.cat((previous_bus, previous_id, header), -1)
        ).reshape(-1, 8, 256)
        output = dict(
            classification_logits=self.classifier(z).squeeze(-1),
            payload_logits=payload_logits,
        )
        nodes = bank[torch.as_tensor(final, device=h.device)]
        return output, ids, nodes

    def forward(self, batch):
        fields, header = self.fields(batch)
        h = self.input_proj(fields)[None]
        for norm, block in zip(self.norms, self.temporal, strict=True):
            h = h + self.dropout(block(norm(h)))
        output, _, _ = self._readout(h[0], header, batch, EventGraphMambaState())
        return output

    @torch.no_grad()
    def stream(self, batch, state=None):
        if self.training:
            raise ValueError("stream requires eval mode")
        state = state or EventGraphMambaState()
        if state.recording:
            if (state.recording, state.source_digest) != (
                batch.recording,
                batch.source_digest,
            ):
                raise ValueError("event state belongs to another recording/source")
        elif batch.row_start != 0:
            raise ValueError("a new event stream must start at physical row zero")
        if state.next_row != batch.row_start:
            raise ValueError(
                "event stream is not contiguous: duplicate or missing rows"
            )
        if float(batch.timestamps[0]) < state.last_timestamp:
            raise ValueError("event stream clock decreased")
        self._routing(batch, state)  # reject capacity errors before mutating caches
        fields, header = self.fields(batch)
        h = self.input_proj(fields)[None]
        caches = []
        for i, (norm, block) in enumerate(zip(self.norms, self.temporal, strict=True)):
            conv, memory = (
                state.caches[i]
                if state.caches
                else block.allocate_inference_cache(1, len(batch.ids))
            )
            out, conv, memory = mamba_chunk(
                block,
                norm(h),
                conv,
                memory,
                official=self.hparams.backend == "official",
            )
            caches.append((conv, memory))
            h = h + out
        output, ids, nodes = self._readout(h[0], header, batch, state)
        state = EventGraphMambaState(
            batch.recording,
            batch.source_digest,
            batch.row_start + len(batch.ids),
            float(batch.timestamps[-1]),
            caches,
            ids,
            nodes,
            h[0, -1],
        )
        return output, state

    def losses(self, output, batch):
        known = batch.scored & (batch.labels >= 0)
        cls = F.binary_cross_entropy_with_logits(
            output["classification_logits"],
            batch.labels.clamp_min(0).float(),
            reduction="none",
        )
        cls = (cls * known).sum() / known.sum().clamp_min(1)
        valid = torch.arange(8, device=batch.ids.device)[None] < batch.lengths[:, None]
        valid = (
            valid
            & batch.scored[:, None]
            & batch.verified_normal
            & batch.payload_length_verified
        )
        byte_nll = F.cross_entropy(
            output["payload_logits"].flatten(0, 1),
            batch.payload.long().flatten(),
            reduction="none",
        ).reshape(-1, 8)
        payload = (byte_nll * valid).sum() / valid.sum().clamp_min(1)
        return cls + self.hparams.payload_weight * payload, dict(
            classification=cls, payload=payload
        )

    def training_step(self, batch, batch_idx):
        output = self(batch)
        loss, parts = self.losses(output, batch)
        self.log_dict(
            {f"train/{k}": v for k, v in parts.items()},
            batch_size=int(batch.scored.sum()),
        )
        return loss

    def _start_scores(self):
        self._stream_state, self._score_parts, self._score_index = None, [], []

    def on_validation_epoch_start(self):
        self._start_scores()

    def on_test_epoch_start(self):
        self._start_scores()

    def _evaluate(self, batch, prefix):
        if batch.row_start == 0:
            self._stream_state = None
        output, self._stream_state = self.stream(batch, self._stream_state)
        _, parts = self.losses(output, batch)
        self.log_dict(
            {f"{prefix}/{k}": v for k, v in parts.items()}, batch_size=len(batch.ids)
        )
        mask = torch.arange(8, device=batch.ids.device)[None] < batch.lengths[:, None]
        mask &= batch.payload_length_verified
        nll = F.cross_entropy(
            output["payload_logits"].flatten(0, 1),
            batch.payload.long().flatten(),
            reduction="none",
        ).reshape(-1, 8)
        anomaly = (nll * mask).sum(-1) / mask.sum(-1).clamp_min(1)
        values = (
            torch.stack(
                (
                    batch.timestamps,
                    batch.ids,
                    batch.labels,
                    output["classification_logits"].sigmoid(),
                    anomaly,
                    mask.any(-1),
                ),
                -1,
            )
            .double()
            .cpu()
            .numpy()
        )
        # Bounded artifacts, one shard per input chunk. No million-object score list.
        if self.trainer.is_global_zero and not self.trainer.sanity_checking:
            directory = (
                Path(self.trainer.default_root_dir)
                / "artifacts"
                / f"{prefix}-events-epoch{self.current_epoch:04d}"
            )
            directory.mkdir(parents=True, exist_ok=True)
            name = f"{len(self._score_index):08d}.npz"
            np.savez(
                directory / name,
                values=values,
                row_start=batch.row_start,
                recording=batch.recording,
                source_digest=batch.source_digest,
            )
        self._score_index.append(
            dict(
                recording=batch.recording,
                row_start=batch.row_start,
                count=len(batch.ids),
            )
        )
        # Only labels and scalar scores for exact source AP; no node states retained.
        self._score_parts.append(values[:, 2:])

    def validation_step(self, batch, batch_idx):
        self._evaluate(batch, "val")

    def test_step(self, batch, batch_idx):
        self._evaluate(batch, "test")

    def _finish_scores(self, prefix):
        if not self._score_parts:
            return
        values = np.concatenate(self._score_parts)
        labels = values[:, 0]
        known = labels >= 0
        metrics = {}
        for head, column in (("classification", 1), ("payload", 2)):
            eligible = (
                known if head == "classification" else known & values[:, 3].astype(bool)
            )
            ap = raw_average_precision(values[eligible, column], labels[eligible])
            if ap is not None:
                metrics[f"{head}_frame_ap"] = ap
                self.log(f"{prefix}/{head}_frame_ap", ap)
        expected = {}
        for chunk in self._score_index:
            key = chunk["recording"]
            if chunk["row_start"] != expected.get(key, 0):
                raise ValueError("duplicate/missing event evaluation rows")
            expected[key] = chunk["row_start"] + chunk["count"]
        if not self.trainer.sanity_checking:
            dm = self.trainer.datamodule
            counts = {
                k: r.count
                for k, r in dm.event_recordings.items()
                if r.recording.role == "val_query"
            }
            if expected != counts:
                raise ValueError(
                    "incomplete event evaluation; every validation frame is required"
                )
            directory = (
                Path(self.trainer.default_root_dir)
                / "artifacts"
                / f"{prefix}-events-epoch{self.current_epoch:04d}"
            )
            (directory / "index.json").write_text(
                json.dumps(
                    dict(
                        schema_version=1,
                        prediction_unit="observed_frame",
                        metrics=metrics,
                        coverage=expected,
                        columns=[
                            "timestamp",
                            "can_id",
                            "label",
                            "classification",
                            "payload_nll",
                            "payload_supported",
                        ],
                        chunks=self._score_index,
                        calibration="unfitted; classification threshold 0.5 is diagnostic only",
                    ),
                    indent=2,
                )
                + "\n"
            )
        self._score_parts = []

    def on_validation_epoch_end(self):
        self._finish_scores("val")

    def on_test_epoch_end(self):
        self._finish_scores("test")

    def on_save_checkpoint(self, checkpoint):
        checkpoint["event_input_contract"] = dict(
            schema_version=1, source_manifest_digest=self._source_manifest_digest
        )

    def on_load_checkpoint(self, checkpoint):
        contract = checkpoint.get("event_input_contract", {})
        if contract.get("schema_version") != 1:
            raise ValueError(
                "checkpoint lacks event input identity; snapshot weights are incompatible"
            )
        if (
            self._source_manifest_digest is not None
            and self._source_manifest_digest != contract["source_manifest_digest"]
        ):
            raise ValueError(
                "event checkpoint source manifest differs from current data"
            )
        self._source_manifest_digest = contract["source_manifest_digest"]

    def configure_optimizers(self):
        return torch.optim.AdamW(
            self.parameters(),
            lr=self.hparams.learning_rate,
            weight_decay=self.hparams.weight_decay,
        )
