"""Source-only, sidecar diagnostics; no production schema changes."""
