"""Bounded-shard frozen readouts. No encoder parameters are optimized."""

from __future__ import annotations

import json
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

from .missed_attacks import aggregate_idbins, write_json


class ProbeData:
    def __init__(self, root):
        self.root = Path(root)
        self.records = {}
        for p in sorted((self.root / "audit").glob("*/identity.json")):
            meta = json.loads(p.read_text())
            if meta["recording"]["role"].endswith("query"):
                self.records[p.parent.name] = meta
        self.idbins = {}

    def files(self, kind, train=False):
        result = []
        for key, meta in self.records.items():
            if train and meta["recording"]["role"] != "train_query":
                continue
            base = self.root / ("audit" if kind == "message" else "embeddings") / key
            result.extend(
                (key, p)
                for p in sorted(
                    base.glob("messages-*.npz" if kind == "message" else "shard-*.npz")
                )
            )
        return result

    def node_labels(self, key, data):
        if key not in self.idbins:
            with np.load(self.root / "audit" / key / "idbins.npz") as z:
                self.idbins[key] = {k: z[k] for k in ("bin", "id", "label")}
        units = self.idbins[key]
        selected = (units["bin"] >= data["bin"][0]) & (units["bin"] <= data["bin"][-1])
        ids = self.records[key]["ids"]
        mapping = {k: i for i, k in enumerate(data["ids"])}
        local_ids = np.array([mapping.get(k, -1) for k in ids])
        node = local_ids[units["id"][selected]]
        label = np.full(data["live"].shape, -1, np.int8)
        valid = node >= 0
        label[units["bin"][selected][valid] - data["bin"][0], node[valid]] = units[
            "label"
        ][selected][valid]
        return label

    def arrays(self, kind, key, path):
        with np.load(path) as z:
            data = {k: z[k] for k in z.files}
        if kind == "message":
            x, y, mask = data["x"], data["label"], None
        elif kind.startswith("pooled"):
            x, y, mask = data["pooled"], data["labels"], None
        elif kind == "node_bin":
            x, y, mask = data["nodes"].astype(np.float32), data["labels"], data["live"]
        else:
            label = self.node_labels(key, data)
            mask = data["observed"] & (label >= 0)
            x, y = data["nodes"][mask].astype(np.float32), label[mask]
            mask = None
        return x, y, mask, data


class BalancePlan:
    def __init__(self, counts, metadata):
        self.counts = counts
        self.metadata = metadata
        self.tree = defaultdict(lambda: defaultdict(set))
        for (key, sign), count in counts.items():
            if not count:
                continue
            m = metadata[key]
            family = m["family"] if sign else "negative"
            self.tree[sign, family][m["recording"]["vehicle"]].add(
                m["recording"]["session"]
            )
        self.group_totals = Counter()
        for (key, sign), count in counts.items():
            m = metadata[key]
            self.group_totals[
                sign,
                m["family"] if sign else "negative",
                m["recording"]["vehicle"],
                m["recording"]["session"],
            ] += count
        self.total = sum(counts.values())

    def weights(self, key, labels):
        result = np.zeros(len(labels), np.float32)
        m = self.metadata[key]
        vehicle, group = m["recording"]["vehicle"], m["recording"]["session"]
        for sign in (0, 1):
            family = m["family"] if sign else "negative"
            tree = self.tree.get((sign, family), {})
            if vehicle not in tree:
                continue
            families = sum(s == sign for s, _ in self.tree)
            total = self.group_totals[sign, family, vehicle, group]
            result[np.asarray(labels) == sign] = (
                self.total * 0.5 / families / len(tree) / len(tree[vehicle]) / total
            )
        return result


def fit_probe(root, kind, device):
    import torch
    import torch.nn.functional as F

    torch.manual_seed(42)
    rng = np.random.default_rng(42)
    source = ProbeData(root)
    files = source.files(kind, train=True)
    counts = Counter()
    total, sums, squares = 0, None, None
    for key, path in files:
        x, y, mask, data = source.arrays(kind, key, path)
        v = x[data["live"]] if kind == "node_bin" else x[y >= 0]
        v = v.astype(np.float64)
        if sums is None:
            sums, squares = np.zeros(v.shape[-1]), np.zeros(v.shape[-1])
        total += len(v)
        sums += v.sum(0)
        squares += (v * v).sum(0)
        for sign in (0, 1):
            counts[key, sign] += int((y == sign).sum())
    center = sums / total
    scale = np.sqrt(np.maximum(squares / total - center * center, 1e-8))
    if kind == "message":
        flags = [*range(8, 16), *range(24, 32), *range(42, 50), 54]
        center[flags] = 0
        scale[flags] = 1
    balance = BalancePlan(counts, source.records)
    dims = len(center)
    head = (
        torch.nn.Sequential(
            torch.nn.Linear(dims, 64), torch.nn.SiLU(), torch.nn.Linear(64, 1)
        )
        if kind == "message"
        else torch.nn.Linear(dims, 1)
    ).to(device)
    opt = torch.optim.Adam(head.parameters(), lr=1e-3, weight_decay=0)
    c = torch.tensor(center, dtype=torch.float32, device=device)
    s = torch.tensor(scale, dtype=torch.float32, device=device)
    target = Path(root) / "probes" / kind
    target.mkdir(parents=True, exist_ok=True)
    write_json(
        target / "normalization.json",
        dict(
            center=center.tolist(),
            scale=scale.tolist(),
            training_units=total,
            training_counts={f"{key}:{sign}": n for (key, sign), n in counts.items()},
            normalization_scope="source train_query only; live nodes for node-bin head",
            seed=42,
        ),
    )
    curve = []
    for epoch in range(10):
        opt.zero_grad()
        accumulated, epoch_loss, epoch_units = 0, 0.0, 0
        # Shard order and within-shard order are fixed by this single seed.
        for index in rng.permutation(len(files)):
            key, path = files[index]
            x, y, mask, _ = source.arrays(kind, key, path)
            order = rng.permutation(np.flatnonzero(y >= 0))
            for start in range(0, len(order), 4096):
                selected = order[start : start + 4096]
                cursor = 0
                while cursor < len(selected):
                    take = selected[cursor : cursor + 4096 - accumulated]
                    cursor += len(take)
                    values = torch.tensor(x[take], dtype=torch.float32, device=device)
                    logits = head((values - c) / s).squeeze(-1)
                    if kind == "node_bin":
                        active = torch.tensor(mask[take], device=device)
                        logits = logits.masked_fill(~active, -1e4).max(-1).values
                    labels = torch.tensor(y[take], dtype=torch.float32, device=device)
                    weight = (
                        np.ones(len(take), np.float32)
                        if kind == "pooled_bce"
                        else balance.weights(key, y[take])
                    )
                    loss = (
                        F.binary_cross_entropy_with_logits(
                            logits, labels, reduction="none"
                        )
                        * torch.tensor(weight, device=device)
                    ).sum()
                    (loss / 4096).backward()
                    accumulated += len(take)
                    epoch_loss += float(loss.detach())
                    epoch_units += len(take)
                    if accumulated == 4096:
                        opt.step()
                        opt.zero_grad()
                        accumulated = 0
        if accumulated:
            for parameter in head.parameters():
                if parameter.grad is not None:
                    parameter.grad.mul_(4096 / accumulated)
            opt.step()
        curve.append(
            dict(
                epoch=epoch + 1,
                loss=epoch_loss / max(1, epoch_units),
                units=epoch_units,
            )
        )
        torch.save(
            dict(
                head=head.state_dict(),
                center=center,
                scale=scale,
                kind=kind,
                epoch=epoch + 1,
            ),
            target / "head.pt",
        )
        write_json(
            target / "training.json",
            dict(
                stage="complete" if epoch == 9 else "running",
                epochs=curve,
                learning_rate=0.001,
                weight_decay=0,
                batch_size=4096,
                validation_selection=False,
            ),
        )
        print("probe", kind, "epoch", epoch + 1, curve[-1], flush=True)
    head.eval()
    # Native predictions in bounded shards; bus-bin arrays are small per recording.
    native = []
    for key, path in source.files(kind):
        x, y, mask, data = source.arrays(kind, key, path)
        folder = target / key
        folder.mkdir(exist_ok=True)
        with torch.inference_mode():
            scores = []
            for start in range(0, len(x), 4096):
                v = torch.tensor(
                    x[start : start + 4096], dtype=torch.float32, device=device
                )
                logits = head((v - c) / s).squeeze(-1)
                if kind == "node_bin":
                    logits = logits.masked_fill(
                        ~torch.tensor(mask[start : start + 4096], device=device), -1e4
                    )
                scores.append(logits.sigmoid().cpu().numpy())
            score = np.concatenate(scores) if scores else np.zeros(0, np.float32)
        if kind == "message":
            output = dict(score=score, label=y, bin=data["bin"], id=data["id"])
        elif kind == "node_id":
            node_labels = source.node_labels(key, data)
            # Score every observed ID-bin, including any unknown labels.
            obs = data["observed"]
            with torch.inference_mode():
                v = torch.tensor(data["nodes"][obs].astype(np.float32), device=device)
                observed_scores = head((v - c) / s).squeeze(-1).sigmoid().cpu().numpy()
            ti, ni = np.nonzero(obs)
            output = dict(
                score=observed_scores,
                label=node_labels[obs],
                bin=data["bin"][ti],
                id=data["ids"][ni],
            )
        elif kind == "node_bin":
            obs = data["observed"]
            node_labels = source.node_labels(key, data)
            ti, ni = np.nonzero(obs)
            output = dict(
                score=score[obs],
                label=node_labels[obs],
                bin=data["bin"][ti],
                id=data["ids"][ni],
                bus_score=score.max(-1),
                bus_bin=data["bin"],
            )
        else:
            output = dict(score=score, label=y, bin=data["bin"])
        np.savez(folder / path.name, **output)
        native.append(dict(recording=key, shard=path.name, units=len(output["score"])))
    write_json(target / "coverage.json", dict(stage="complete", shards=native))


def collect_predictions(root, kind, key, size):
    folder = Path(root) / "probes" / kind / key
    bus = np.zeros(size, np.float32)
    native = defaultdict(list)
    for path in sorted(folder.glob("*.npz")):
        with np.load(path) as z:
            for field in ("score", "label", "bin", "id"):
                if field in z:
                    native[field].append(z[field])
            if "bus_score" in z:
                bus[z["bus_bin"]] = z["bus_score"]
            else:
                np.maximum.at(bus, z["bin"], z["score"])
    values = {k: np.concatenate(v) for k, v in native.items()}
    idunits = (
        aggregate_idbins(values["score"], values["label"], values["bin"], values["id"])
        if "id" in values
        else None
    )
    return bus, values, idunits


def verify_prediction_coverage(root, kind, source):
    """Check every persisted native prediction against its input shard identity."""
    root = Path(root)
    marker = root / "probes" / kind / "verified-coverage.json"
    inputs = source.files(kind)
    if marker.exists() and json.loads(marker.read_text()).get("stage") == "complete":
        checked = marker.stat().st_mtime_ns
        paths = [p for _, p in inputs]
        paths += [root / "probes" / kind / key / p.name for key, p in inputs]
        paths += [
            root / "audit" / key / name
            for key in source.records
            for name in ("identity.json", "bins.npz", "idbins.npz")
        ]
        expected = defaultdict(set)
        for key, path in inputs:
            expected[key].add(path.name)
        unchanged = all(
            path.exists() and path.stat().st_mtime_ns <= checked for path in paths
        )
        unchanged &= all(
            {p.name for p in (root / "probes" / kind / key).glob("*.npz")} == names
            for key, names in expected.items()
        )
        if unchanged:
            return  # Only report arithmetic changed; retain prior exact coverage proof.
    records = {}
    expected_paths = defaultdict(set)
    for key, path in inputs:
        expected_paths[key].add(path.name)
        prediction = root / "probes" / kind / key / path.name
        with np.load(path) as x, np.load(prediction) as y:
            if kind == "message":
                for field in ("label", "bin", "id"):
                    np.testing.assert_array_equal(x[field], y[field])
                expected = len(x["label"])
            elif kind.startswith("pooled"):
                np.testing.assert_array_equal(x["bin"], y["bin"])
                np.testing.assert_array_equal(x["labels"], y["label"])
                expected = len(x["bin"])
            else:
                ti, ni = np.nonzero(x["observed"])
                np.testing.assert_array_equal(x["bin"][ti], y["bin"])
                np.testing.assert_array_equal(x["ids"][ni], y["id"])
                expected = len(ti)
                if kind == "node_bin":
                    np.testing.assert_array_equal(x["bin"], y["bus_bin"])
                    assert len(y["bus_score"]) == len(x["bin"])
            assert len(y["score"]) == expected
            records[key] = records.get(key, 0) + expected
    audit = json.loads((root / "audit/audit.json").read_text())
    for key, expected_files in expected_paths.items():
        actual = {p.name for p in (root / "probes" / kind / key).glob("*.npz")}
        assert actual == expected_files, (kind, key, "missing/extra prediction shards")
        if kind == "message":
            expected = audit["recordings"][source.records[key]["recording"]["key"]][
                "frames"
            ]
        else:
            with np.load(
                root
                / "audit"
                / key
                / ("bins.npz" if kind.startswith("pooled") else "idbins.npz")
            ) as z:
                expected = len(z["label"])
        assert records[key] == expected, (kind, key, records[key], expected)
    write_json(
        root / "probes" / kind / "verified-coverage.json",
        dict(
            stage="complete",
            units_by_recording=records,
            exact_input_shard_identity=True,
            no_missing_or_extra_shards=True,
        ),
    )
