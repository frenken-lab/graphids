"""Auditable source-only helpers. Importing this module does not import torch."""

from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path

import numpy as np

CHECKPOINT_SHA256 = "e513006088ffd06a6135a21dcc30fdf208ae1aed17ddbcdaeecb30c6ca86dcc6"


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, allow_nan=False))
    temp.replace(path)


def physical_bins(times, width=0.01):
    """Same half-open boundary tolerance as production build_snapshots."""
    offsets = (np.asarray(times) - times[0]) / width
    near = np.rint(offsets)
    return np.floor(np.where(np.abs(offsets - near) < 1e-5, near, offsets)).astype(
        np.int64
    )


def source_manifest(path, destination):
    from graphids.core.data.snapshots.manifest import CANRecordingManifest

    CANRecordingManifest.load(path, verify_files=False)
    raw = json.loads(Path(path).read_text())
    raw["records"] = [
        r for r in raw["records"] if r["role"].startswith(("train_", "val_"))
    ]
    for rec in raw["records"]:
        rec["path"] = str((Path(path).parent / rec["path"]).resolve())
    keys = {r["key"] for r in raw["records"]}
    raw["attack_families"] = {
        k: v for k, v in raw["attack_families"].items() if k in keys
    }
    # Validates capture-group role separation before opening any recording file.
    write_json(destination, raw)
    return CANRecordingManifest.load(destination)


def causal_messages(rows, profiles=None, payload_valid=True):
    """Current/previous same-ID bytes+masks, gap, preceding 80ms count,
    byte differences, four normal-reference profiles and profile availability.
    No cross-ID, future, interface, or recording-identity inputs.
    """
    profiles = profiles or {}
    x = np.zeros((len(rows), 55), np.float32)
    indices = defaultdict(list)
    times = np.array([row["time"] for row in rows])
    for i, row in enumerate(rows):
        indices[row["id"]].append(i)
        data = row["data"]
        x[i, : len(data)] = np.frombuffer(data, np.uint8) / 255
        if payload_valid:
            x[i, 8 : 8 + len(data)] = 1
    for key, members in indices.items():
        idx = np.asarray(members)
        earlier, current = idx[:-1], idx[1:]
        x[current, 16:24] = x[earlier, :8]
        x[current, 24:32] = x[earlier, 8:16]
        x[current, 32] = np.diff(times[idx])
        # searchsorted on same-ID times is causal even for equal-time frames:
        # subtract from arrival position, never from the last equal timestamp.
        x[idx, 33] = np.arange(len(idx)) - np.searchsorted(
            times[idx], times[idx] - 0.08, side="left"
        )
        x[current, 34:42] = x[current, :8] - x[current, 16:24]
        x[current, 42:50] = x[current, 8:16] * x[current, 24:32]
        if key in profiles:
            x[idx, 50:54] = profiles[key]
            x[idx, 54] = 1
    return x


def observed_idbins(rows, bins):
    groups = defaultdict(list)
    for i, (row, b) in enumerate(zip(rows, bins, strict=True)):
        groups[int(b), row["id"]].append(i)
    result = []
    for (b, key), indices in sorted(groups.items()):
        labels = [rows[i]["label"] for i in indices]
        attackers = [i for i in indices if rows[i]["label"] == 1]
        last_attack = attackers[-1] if attackers else -1
        result.append(
            dict(
                bin=b,
                id=key,
                label=1 if attackers else (0 if all(v == 0 for v in labels) else -1),
                count=len(indices),
                attacker_frames=len(attackers),
                attacker_fraction=len(attackers) / len(indices),
                final_attacker=rows[indices[-1]]["label"] == 1,
                attack_payload_survives=bool(attackers)
                and any(
                    rows[i]["data"] == rows[indices[-1]]["data"] for i in attackers
                ),
                legitimate_after_attack=sum(
                    i > last_attack and rows[i]["label"] == 0 for i in indices
                )
                if attackers
                else 0,
                changed=len({rows[i]["data"] for i in indices}) > 1,
                first_line=indices[0] + 2,
                last_line=indices[-1] + 2,
            )
        )
    return result


def hierarchical_weights(labels, families, vehicles, groups):
    """Each sign gets half; positives split family/vehicle/group then unit.
    Related variants in a capture group divide its allocation.
    Unknown labels receive zero. All inputs must be training units.
    """
    labels = np.asarray(labels)
    weights = np.zeros(len(labels), np.float64)
    for sign in (0, 1):
        tree = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
        for i in np.flatnonzero(labels == sign):
            tree[families[i] if sign else "negative"][vehicles[i]][groups[i]].append(i)
        for vehicle_tree in tree.values():
            for group_tree in vehicle_tree.values():
                for indices in group_tree.values():
                    weights[indices] = (
                        0.5
                        / len(tree)
                        / len(vehicle_tree)
                        / len(group_tree)
                        / len(indices)
                    )
    return weights


def aggregate_max(scores, indices, size):
    out = np.zeros(size, np.float32)
    np.maximum.at(out, indices, scores)
    return out


def metrics(scores, labels, threshold=0.5):
    from graphids.core.models.score_columns import raw_average_precision

    scores, labels = np.asarray(scores, dtype=np.float64), np.asarray(labels)
    known = (labels >= 0) & np.isfinite(scores)
    scores, labels = scores[known], labels[known]
    pred, pos = scores >= threshold, labels == 1
    tp, fp, fn, tn = (
        int(a.sum()) for a in (pred & pos, pred & ~pos, ~pred & pos, ~pred & ~pos)
    )
    return dict(
        n=len(labels),
        positive=int(pos.sum()),
        ap=raw_average_precision(scores, labels),
        threshold=float(threshold),
        tp=tp,
        fp=fp,
        fn=fn,
        tn=tn,
        precision=tp / max(1, tp + fp),
        recall=tp / max(1, tp + fn),
        f1=2 * tp / max(1, 2 * tp + fp + fn),
    )


def normal_budgets(scores, labels, normal, exposure):
    """Pooled empirical normal thresholds, >= ties; never silently exceed budget."""
    scores = np.asarray(scores, dtype=np.float64)
    # Terminal boundary observations can have zero exposure and still alert.
    normal = np.asarray(normal, bool) & (np.asarray(labels) == 0)
    values = np.asarray(scores)[normal]
    hours = float(np.asarray(exposure)[normal].sum() / 3600)
    result = {}
    if not len(values) or not hours:
        return {"unavailable": "no supported normal exposure"}
    ordered = np.sort(values)[::-1]
    for budget in (0, 10, 100):
        allowed = min(len(ordered), int(np.floor(budget * hours)))
        threshold = (
            np.nextafter(float(ordered[allowed]), np.inf)
            if allowed < len(ordered)
            else float(ordered[-1])
        )
        false = int((values >= threshold).sum())
        pos = np.asarray(labels) == 1
        result[str(budget)] = dict(
            threshold=threshold,
            normal_hours=hours,
            false_bins=false,
            achieved_per_hour=false / hours,
            boundary_ties=int(
                (values == ordered[min(allowed, len(ordered) - 1)]).sum()
            ),
            recall=float((np.asarray(scores)[pos] >= threshold).mean())
            if pos.any()
            else None,
        )
    return result


class ByteTransitions:
    """Sparse smoothed counts; normal source train only, conditioned on prior byte."""

    def __init__(self, alpha=1.0):
        self.alpha = alpha
        self.marginal = {}
        self.transitions = {}

    def fit(self, streams):
        for rows in streams:
            by_id = defaultdict(list)
            for r in rows:
                by_id[r["id"]].append(r["data"])
            for key, payloads in by_id.items():
                lengths = np.array([len(p) for p in payloads])
                values = np.frombuffer(
                    b"".join(p.ljust(8, b"\0") for p in payloads), np.uint8
                ).reshape(-1, 8)
                for j in range(8):
                    valid = lengths > j
                    if not valid.any():
                        continue
                    k = key, j
                    counts = np.bincount(values[valid, j], minlength=256)
                    self.marginal[k] = (
                        self.marginal.get(k, np.zeros(256, np.int64)) + counts
                    )
                    paired = valid[:-1] & valid[1:]
                    joint = (
                        values[:-1, j][paired].astype(np.int64) * 256
                        + values[1:, j][paired]
                    )
                    table = np.bincount(joint, minlength=65536).reshape(256, 256)
                    for previous in np.flatnonzero(table.sum(1)):
                        k = key, j, int(previous)
                        self.transitions[k] = (
                            self.transitions.get(k, np.zeros(256, np.int64))
                            + table[previous]
                        )
        return self

    def score(self, rows):
        previous, scores = {}, np.full(len(rows), np.nan)
        conditional_cache, marginal_cache = {}, {}
        for i, r in enumerate(rows):
            key, data = r["id"], r["data"]
            nll = []
            for j, byte in enumerate(data):
                marginal_key = key, j
                if marginal_key not in self.marginal:
                    continue
                if key in previous and j < len(previous[key]):
                    k = key, j, previous[key][j]
                    if k not in conditional_cache:
                        counts = self.transitions.get(k)
                        conditional_cache[k] = (
                            -np.log(
                                (counts + self.alpha)
                                / (counts.sum() + 256 * self.alpha)
                            )
                            if counts is not None
                            else np.full(256, np.log(256.0))
                        )
                    nll.append(conditional_cache[k][byte])
                else:
                    if marginal_key not in marginal_cache:
                        counts = self.marginal[marginal_key]
                        marginal_cache[marginal_key] = -np.log(
                            (counts + self.alpha) / (counts.sum() + 256 * self.alpha)
                        )
                    nll.append(marginal_cache[marginal_key][byte])
            if nll:
                scores[i] = sum(nll) / len(nll)
            previous[key] = data
        return scores


def aggregate_idbins(scores, labels, bins, ids):
    """Max score, positive precedence, and unknown unless every frame is known."""
    if not len(scores):
        return np.zeros(0, np.float32), np.zeros(0, np.int8)
    _, local_ids = np.unique(ids, return_inverse=True)
    codes = np.asarray(bins, np.int64) * (int(local_ids.max()) + 1) + local_ids
    _, inverse = np.unique(codes, return_inverse=True)
    size = int(inverse.max()) + 1
    maximum = aggregate_max(scores, inverse, size)
    positive = np.zeros(size, bool)
    unknown = np.zeros(size, bool)
    np.logical_or.at(positive, inverse, np.asarray(labels) == 1)
    np.logical_or.at(unknown, inverse, np.asarray(labels) < 0)
    return maximum, np.where(positive, 1, np.where(unknown, -1, 0))


def step_contributions(windows):
    """Reproduce a DDP step's global masked mean, attributed to window families."""
    denominators = {
        name: sum(w["denominators"][name] for w in windows)
        for name in ("classification", "count", "change", "new_id")
    }
    contributions = defaultdict(lambda: defaultdict(float))
    for window in windows:
        for name, total in window["numerators"].items():
            contributions[window["family"]][name] += total / max(1, denominators[name])
    return {family: dict(values) for family, values in contributions.items()}
