"""SLURM submission for experiment YAML configs."""

from __future__ import annotations

import hashlib
import math
import re
import shlex
import subprocess
from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path

import yaml

from graphids.exp.config import ExperimentConfig
from graphids.paths import PROJECT_ROOT, env_value, slurm_log_dir


@dataclass(frozen=True)
class SlurmSubmitResult:
    command: tuple[str, ...]
    script_path: Path
    script: str
    job_id: str | None = None
    stdout: str = ""


def _slug(value: str) -> str:
    slug = re.sub(r"[^A-Za-z0-9_.-]+", "_", value).strip("_")
    return slug[:120] or "graphids"


def _log_dir() -> Path:
    return slurm_log_dir()


def _script_dir() -> Path:
    return _log_dir() / "scripts"


def _submission_yaml(cfg: ExperimentConfig) -> tuple[Path, str]:
    expanded = yaml.safe_dump(cfg.model_dump(mode="json"), sort_keys=False)
    digest = hashlib.sha256(expanded.encode()).hexdigest()[:16]
    path = _script_dir() / f"{_slug(cfg.experiment_name)}-{digest}.yml"
    return path, expanded


def _workers(cfg: ExperimentConfig) -> int:
    devices = cfg.config.get("trainer", {}).get("devices", 1)
    return devices if isinstance(devices, int) and devices > 0 else 1


def _cpus(cfg: ExperimentConfig) -> int:
    return max(1, int(cfg.resources.cpus_per_worker)) * _workers(cfg)


def _gpus(cfg: ExperimentConfig) -> int:
    requested = int(math.ceil(float(cfg.resources.gpus_per_worker)))
    if cfg.resources.accelerator == "gpu":
        return max(1, requested) * _workers(cfg)
    return max(0, requested) * _workers(cfg)


def _sbatch_directives(
    cfg: ExperimentConfig,
    *,
    job_name: str,
    cluster: str | None,
    partition: str | None,
    time_limit: str | None,
    gres: str | None,
) -> list[str]:
    resources = cfg.resources
    gpus = _gpus(cfg)
    resolved_partition = partition or resources.partition or ("gpu" if gpus else "cpu")
    resolved_time = time_limit or resources.time_limit or "01:00:00"
    resolved_gres = gres or resources.gres or (f"gpu:{gpus}" if gpus else None)
    resolved_account = resources.account or env_value("GRAPHIDS_SLURM_ACCOUNT")

    lines = [
        "#SBATCH --nodes=1",
        "#SBATCH --ntasks=1",
        f"#SBATCH --job-name={job_name}",
        f"#SBATCH --partition={resolved_partition}",
        f"#SBATCH --time={resolved_time}",
        f"#SBATCH --cpus-per-task={_cpus(cfg)}",
    ]
    if cluster or resources.cluster:
        lines.append(f"#SBATCH --clusters={cluster or resources.cluster}")
    if resolved_gres:
        lines.append(f"#SBATCH --gres={resolved_gres}")
    if resources.memory_gb is not None:
        lines.append(f"#SBATCH --mem={int(resources.memory_gb)}G")
    if resolved_account:
        lines.append(f"#SBATCH --account={resolved_account.lower()}")
    return lines


def build_slurm_script(
    cfg: ExperimentConfig,
    yaml_path: str | Path,
    *,
    cluster: str | None = None,
    partition: str | None = None,
    time_limit: str | None = None,
    gres: str | None = None,
    nodes: int = 1,
    ray_port: int = 6379,
) -> tuple[Path, str]:
    """Build a SLURM script that starts Ray inside one allocation."""
    yaml_abs = Path(yaml_path).resolve()
    if not yaml_abs.is_file():
        raise FileNotFoundError(f"experiment YAML not found: {yaml_abs}")

    yaml_abs, _ = _submission_yaml(cfg)
    job_name = _slug(f"ray-{cfg.experiment_name}")
    log_dir = _log_dir()
    script_dir = _script_dir()
    script_path = script_dir / f"{job_name}.sbatch"
    stdout_path = log_dir / f"{job_name}_%j.out"
    stderr_path = log_dir / f"{job_name}_%j.err"
    directives = _sbatch_directives(
        cfg,
        job_name=job_name,
        cluster=cluster,
        partition=partition,
        time_limit=time_limit,
        gres=gres,
    )
    directives[0] = f"#SBATCH --nodes={max(1, int(nodes))}"
    directives[1] = "#SBATCH --ntasks-per-node=1"
    directives.extend(
        [
            f"#SBATCH --output={stdout_path}",
            f"#SBATCH --error={stderr_path}",
        ]
    )
    gpus = _gpus(cfg)
    cpus = _cpus(cfg)
    script = "\n".join(
        [
            "#!/usr/bin/env bash",
            *directives,
            "",
            "set -euo pipefail",
            f"cd {shlex.quote(str(PROJECT_ROOT))}",
            "source scripts/slurm/_preamble.sh",
            "",
            f"export SLURM_CPUS_PER_TASK={cpus}",
            "RAY_BASE_PORT=${GRAPHIDS_RAY_BASE_PORT:-$((20000 + (SLURM_JOB_ID % 200) * 200))}",
            "RAY_PORT=${GRAPHIDS_RAY_PORT:-${RAY_BASE_PORT}}",
            'RAY_OBJECT_MANAGER_PORT="$((RAY_BASE_PORT + 1))"',
            'RAY_NODE_MANAGER_PORT="$((RAY_BASE_PORT + 2))"',
            'RAY_DASHBOARD_AGENT_PORT="$((RAY_BASE_PORT + 4))"',
            'RAY_DASHBOARD_AGENT_GRPC_PORT="$((RAY_BASE_PORT + 5))"',
            'RAY_RUNTIME_ENV_AGENT_PORT="$((RAY_BASE_PORT + 6))"',
            'RAY_METRICS_EXPORT_PORT="$((RAY_BASE_PORT + 7))"',
            'RAY_MIN_WORKER_PORT="$((RAY_BASE_PORT + 20))"',
            'RAY_MAX_WORKER_PORT="$((RAY_BASE_PORT + 119))"',
            f"RAY_LOG_DIR={log_dir}/ray_${{SLURM_JOB_ID}}",
            'RAY_TMP_DIR="${TMPDIR:-/tmp}/graphids-ray-${SLURM_JOB_ID}"',
            'mkdir -p "${RAY_LOG_DIR}" "${RAY_TMP_DIR}"',
            "RAY_START_PIDS=()",
            'mapfile -t RAY_NODES < <(scontrol show hostnames "${SLURM_JOB_NODELIST}")',
            'HEAD_NODE="${RAY_NODES[0]}"',
            "HEAD_IP=$(srun --nodes=1 --ntasks=1 -w \"${HEAD_NODE}\" hostname --ip-address | awk '{print $1}')",
            'RAY_ADDRESS="${HEAD_IP}:${RAY_PORT}"',
            "export RAY_ADDRESS",
            "cleanup_ray() {",
            "  if ((${#RAY_START_PIDS[@]})); then",
            '    kill "${RAY_START_PIDS[@]}" >/dev/null 2>&1 || true',
            '    wait "${RAY_START_PIDS[@]}" >/dev/null 2>&1 || true',
            "  fi",
            '  rm -rf "${RAY_TMP_DIR}"',
            "}",
            "trap cleanup_ray EXIT",
            "",
            'mkdir -p "${RAY_LOG_DIR}" "${RAY_TMP_DIR}"',
            'srun --nodes=1 --ntasks=1 -w "${HEAD_NODE}" \\',
            '  ray start --head --node-ip-address="${HEAD_IP}" --port="${RAY_PORT}" \\',
            "    --include-dashboard=false \\",
            '    --object-manager-port="${RAY_OBJECT_MANAGER_PORT}" \\',
            '    --node-manager-port="${RAY_NODE_MANAGER_PORT}" \\',
            '    --dashboard-agent-listen-port="${RAY_DASHBOARD_AGENT_PORT}" \\',
            '    --dashboard-agent-grpc-port="${RAY_DASHBOARD_AGENT_GRPC_PORT}" \\',
            '    --runtime-env-agent-port="${RAY_RUNTIME_ENV_AGENT_PORT}" \\',
            '    --metrics-export-port="${RAY_METRICS_EXPORT_PORT}" \\',
            '    --min-worker-port="${RAY_MIN_WORKER_PORT}" \\',
            '    --max-worker-port="${RAY_MAX_WORKER_PORT}" \\',
            f'    --num-cpus={cpus} --num-gpus={gpus} --temp-dir="${{RAY_TMP_DIR}}/head" \\',
            '    --block >"${RAY_LOG_DIR}/head.log" 2>&1 &',
            'RAY_START_PIDS+=("$!")',
            "sleep 10",
            "",
            'for NODE in "${RAY_NODES[@]:1}"; do',
            '  srun --nodes=1 --ntasks=1 -w "${NODE}" \\',
            '    ray start --address="${RAY_ADDRESS}" \\',
            f'      --num-cpus={cpus} --num-gpus={gpus} --temp-dir="${{RAY_TMP_DIR}}/${{NODE}}" \\',
            '      --block >"${RAY_LOG_DIR}/${NODE}.log" 2>&1 &',
            '  RAY_START_PIDS+=("$!")',
            "done",
            "sleep 10",
            "",
            f'python -m graphids exp launch {shlex.quote(str(yaml_abs))} --address "${{RAY_ADDRESS}}"',
            "source scripts/slurm/_epilog.sh",
            "",
        ]
    )
    return script_path, script


def submit_experiment(
    cfg: ExperimentConfig,
    yaml_path: str | Path,
    *,
    cluster: str | None = None,
    partition: str | None = None,
    time_limit: str | None = None,
    gres: str | None = None,
    nodes: int = 1,
    dry_run: bool = False,
    sbatch: str = "sbatch",
) -> SlurmSubmitResult:
    cfg.build_run(name=cfg.experiment_name, stage=cfg.stage, config=cfg.config)
    script_path, script = build_slurm_script(
        cfg,
        yaml_path,
        cluster=cluster,
        partition=partition,
        time_limit=time_limit,
        gres=gres,
        nodes=nodes,
    )
    command: Sequence[str] = (sbatch, str(script_path))
    if dry_run:
        return SlurmSubmitResult(
            command=tuple(command), script_path=script_path, script=script
        )

    script_path.parent.mkdir(parents=True, exist_ok=True)
    config_path, expanded = _submission_yaml(cfg)
    config_path.write_text(expanded)
    script_path.write_text(script)
    completed = subprocess.run(
        command,
        check=True,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )
    match = re.search(r"Submitted batch job\s+(\S+)", completed.stdout)
    return SlurmSubmitResult(
        command=tuple(command),
        script_path=script_path,
        script=script,
        job_id=match.group(1) if match else None,
        stdout=completed.stdout,
    )
